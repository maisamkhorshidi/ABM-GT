clc
clear all
load Runoff_SRI.mat
Runoff_SRI=Runoff_SRI';
Runoff_SRI=reshape(Runoff_SRI,[492,1]);