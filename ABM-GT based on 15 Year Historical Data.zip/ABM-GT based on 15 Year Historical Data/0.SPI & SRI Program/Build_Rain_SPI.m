clc
clear all
load Rain_SPI.mat
Rain_SPI=Rain_SPI';
Rain_SPI=reshape(Rain_SPI,[492,1]);