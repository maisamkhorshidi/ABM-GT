clc
clear
load Coal_11_MATLAB_ABM.mat
all_gr=cell(3,1);
for i=1:3
    all_gr{i}=zeros(60,4);
    all_gr{i}(:,1)=Coal_11_all_gr_1{i}'.*1e6;
    all_gr{i}(:,2)=Coal_11_all_gr_2{i}'.*1e6;
    all_gr{i}(:,3)=Coal_11_all_gr_3{i}'.*1e6;
    all_gr{i}(:,4)=Coal_11_all_gr_4{i}'.*1e6;
end
load Data_GW_Darab_FEM.mat
load Darab_GW_Calibration_FEM.mat
% Assessing Inputs and Parameters For MONTHLY Usage
% Input
% Reading Data Of Region
region_cell_1=xlsread('Row & Columns of GW FEM.xlsx','Sheet1','A3:C63');
region_cell_2=xlsread('Row & Columns of GW FEM.xlsx','Sheet1','D3:F57');
region_cell_3=xlsread('Row & Columns of GW FEM.xlsx','Sheet1','G3:I86');
region_cell_4=xlsread('Row & Columns of GW FEM.xlsx','Sheet1','J3:L117');
well_location=xlsread('GroundWater Flow_FEM.xlsx','Wells','I2:J2000');
% Determining Wells Region
well_region=zeros(size(well_location,1),1);
for i=1:size(well_location,1)
    for j=1:size(region_cell_1,1)
        if well_location(i,1)==region_cell_1(j,1) && well_location(i,2)>=region_cell_1(j,2) &&...
                well_location(i,2)<=region_cell_1(j,3)
            well_region(i)=1;
        end
    end
    for k=1:size(region_cell_2,1)
        if well_location(i,1)==region_cell_2(k,1) && well_location(i,2)>=region_cell_2(k,2) &&...
                well_location(i,2)<=region_cell_2(k,3)
            well_region(i)=2;
        end
    end
    for l=1:size(region_cell_3,1)
        if well_location(i,1)==region_cell_3(l,1) && well_location(i,2)>=region_cell_3(l,2) &&...
                well_location(i,2)<=region_cell_3(l,3)
            well_region(i)=3;
        end
    end
    for m=1:size(region_cell_4,1)
        if well_location(i,1)==region_cell_4(m,1) && well_location(i,2)>=region_cell_4(m,2) &&...
                well_location(i,2)<=region_cell_4(m,3)
            well_region(i)=4;
        end
    end
end
% Determining Well Cell Regions
well_cell_1=zeros(size(region_cell));
well_cell_2=zeros(size(region_cell));
well_cell_3=zeros(size(region_cell));
well_cell_4=zeros(size(region_cell));
for i=1:size(well_location,1)
    well_cell_1(well_location(i,2),well_location(i,1))=(well_region(i)==1);
    well_cell_2(well_location(i,2),well_location(i,1))=(well_region(i)==2);
    well_cell_3(well_location(i,2),well_location(i,1))=(well_region(i)==3);
    well_cell_4(well_location(i,2),well_location(i,1))=(well_region(i)==4);
end
% Well Grids
well_grid_1=zeros(size(x));
well_grid_2=zeros(size(x));
well_grid_3=zeros(size(x));
well_grid_4=zeros(size(x));
for i=2:size(x,1)-1
    for j=2:size(y,2)-1
        well_grid_1(i+1,j+1)=well_cell_1(i,j);
        well_grid_2(i+1,j+1)=well_cell_2(i,j);
        well_grid_3(i+1,j+1)=well_cell_3(i,j);
        well_grid_4(i+1,j+1)=well_cell_4(i,j);
    end
end
% Determining Each Region's number of wells
num_well_region_1=sum(well_region==1);
num_well_region_2=sum(well_region==2);
num_well_region_3=sum(well_region==3);
num_well_region_4=sum(well_region==4);
% Running Darab's GW FEM
num_data=60;
dr=cell(3,1);
mean_dr=cell(3,1);
for scen=1:3
    dr{scen}=cell(60,1);
    mean_dr{scen}=zeros(60,1);
    sum_dr=zeros(size(region_grid));
    for i=1:num_data
        if i<10
            nn='00';
        elseif i<100
            nn='0';
        else
            nn=[];
        end
        %%%%%%%%%%%%%%%%%%%%%%%%% GW FEM COMMAND %%%%%%%%%%%%%%%%%%%%%%%%
        dr1=Darab_FEM_all_dr(all_gr{scen}(i,:),well_grid_1,well_grid_2,well_grid_3,well_grid_4,...
            num_well_region_1,num_well_region_2,num_well_region_3,num_well_region_4,...
            num_node,region_grid,river_grid,river_elev_grid,x,y,d,con_table,...
            con_table_i,con_table_j,kx_cell,ky_cell,q_bc_grid,elev_grid);
        sum_dr=sum_dr+dr1;
        dr{scen}{i}=sum_dr;
        dr{scen}{i}(region_grid==0)=0;
        mean_dr{scen}(i)=sum(sum(dr{scen}{i}))./sum(sum(region_grid));
        disp(['GW Contour Month # ' num2str(i) ' of ' num2str(num_data) ' ; mean dr= ' num2str(mean_dr{scen}(i))])
        dr{scen}{i}(region_grid==0)=0/0;
        figure(1);
        [c,h]=contourf(x,y,dr{scen}{i});
        clabel(c,h);
        ylabel('Y (m)');
        xlabel('X (m)');
        title(['Monthly Discharge ' num2str(sum(round(all_gr{scen}(i,1:4)/1e6.*100)./100)) ...
            ' MCM , Mean Drawdown ' num2str(round(mean_dr{scen}(i)*100)/100)]);
        saveas(figure(1),['Contour - ' num2str(scen) ' - ' nn num2str(i) '.png']);
        dr{scen}{i}(region_grid==0)=0;
        figure(2)
        surf(x,y,dr{scen}{i})
        ylabel('Y (m)');
        xlabel('X (m)');
        zlabel('dr (m)');
        title(['Monthly Discharge ' num2str(sum(round(all_gr{scen}(i,1:4)/1e6.*100)./100)) ...
            ' MCM , Mean Drawdown ' num2str(round(mean_dr{scen}(i)*100)/100)]);
        saveas(figure(2),['3D - ' num2str(scen) ' - ' nn num2str(i) '.png']);
    end
    all_gr{scen}=all_gr{scen}./1e6;
end
save('Rudbal_FEM_Sequence_Run_Database.mat','all_gr','dr',...
    'num_well_region_1','num_well_region_2','num_well_region_3','num_well_region_4');