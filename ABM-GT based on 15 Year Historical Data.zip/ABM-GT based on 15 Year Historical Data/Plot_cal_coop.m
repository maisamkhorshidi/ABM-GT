clc
clear
load('Coal_11_MATLAB_ABM.mat')
dd=cell(3,1);
ss=cell(3,1);
inf=cell(3,1);
rr=cell(3,1);
gw=cell(3,1);
for i=1:3
%     dd{i}=Demand_1{i}+Demand_2{i}+Demand_3{i}+Demand_4{i}+Demand_dr{i}+Demand_e{i}+Demand_i{i};
    ss{i}=Coal_11_S{i}(2:61)';
    inf{i}=Inflow{i};
    rr{i}=Coal_11_R{i}';
    gw{i}=Coal_11_Allocation_gr{i}';
end
save('plot_cal_coop.mat','dd','ss','inf','rr','gw');
clear
load('plot_cal_coop.mat')