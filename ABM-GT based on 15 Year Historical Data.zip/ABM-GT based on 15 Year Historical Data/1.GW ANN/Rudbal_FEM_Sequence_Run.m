clc
clear
load Data_GW_Darab_FEM.mat
load Darab_GW_Calibration_FEM.mat
% Assessing Inputs and Parameters For MONTHLY Usage
% Input
Q_month_max=0.8; % MCM/month
Q_month_min=0; % MCM/month
q_segment=4;
q_max=Q_month_max*1e6; % m^3/month
q_min=Q_month_min*1e6; % m^3/month
% Reading Data Of Region
region_cell_1=xlsread('Row & Columns of GW FEM.xlsx','Sheet1','A3:C63');
region_cell_2=xlsread('Row & Columns of GW FEM.xlsx','Sheet1','D3:F57');
region_cell_3=xlsread('Row & Columns of GW FEM.xlsx','Sheet1','G3:I86');
region_cell_4=xlsread('Row & Columns of GW FEM.xlsx','Sheet1','J3:L117');
well_location=xlsread('GroundWater Flow_FEM.xlsx','Wells','I2:J2000');
% Determining Wells Region
well_region=zeros(size(well_location,1),1);
for i=1:size(well_location,1)
    for j=1:size(region_cell_1,1)
        if well_location(i,1)==region_cell_1(j,1) && well_location(i,2)>=region_cell_1(j,2) &&...
                well_location(i,2)<=region_cell_1(j,3)
            well_region(i)=1;
        end
    end
    for k=1:size(region_cell_2,1)
        if well_location(i,1)==region_cell_2(k,1) && well_location(i,2)>=region_cell_2(k,2) &&...
                well_location(i,2)<=region_cell_2(k,3)
            well_region(i)=2;
        end
    end
    for l=1:size(region_cell_3,1)
        if well_location(i,1)==region_cell_3(l,1) && well_location(i,2)>=region_cell_3(l,2) &&...
                well_location(i,2)<=region_cell_3(l,3)
            well_region(i)=3;
        end
    end
    for m=1:size(region_cell_4,1)
        if well_location(i,1)==region_cell_4(m,1) && well_location(i,2)>=region_cell_4(m,2) &&...
                well_location(i,2)<=region_cell_4(m,3)
            well_region(i)=4;
        end
    end
end
% Determining Well Cell Regions
well_cell_1=zeros(size(region_cell));
well_cell_2=zeros(size(region_cell));
well_cell_3=zeros(size(region_cell));
well_cell_4=zeros(size(region_cell));
for i=1:size(well_location,1)
    well_cell_1(well_location(i,2),well_location(i,1))=(well_region(i)==1);
    well_cell_2(well_location(i,2),well_location(i,1))=(well_region(i)==2);
    well_cell_3(well_location(i,2),well_location(i,1))=(well_region(i)==3);
    well_cell_4(well_location(i,2),well_location(i,1))=(well_region(i)==4);
end
% Well Grids
well_grid_1=zeros(size(x));
well_grid_2=zeros(size(x));
well_grid_3=zeros(size(x));
well_grid_4=zeros(size(x));
for i=2:size(x,1)-1
    for j=2:size(y,2)-1
        well_grid_1(i+1,j+1)=well_cell_1(i,j);
        well_grid_2(i+1,j+1)=well_cell_2(i,j);
        well_grid_3(i+1,j+1)=well_cell_3(i,j);
        well_grid_4(i+1,j+1)=well_cell_4(i,j);
    end
end
% Determining Each Region's number of wells
num_well_region_1=sum(well_region==1);
num_well_region_2=sum(well_region==2);
num_well_region_3=sum(well_region==3);
num_well_region_4=sum(well_region==4);
% Determining input Database
object=cell(1,4);
object{1}=q_min:(q_max-q_min)/q_segment:q_max;
object{2}=q_min:(q_max-q_min)/q_segment:q_max;
object{3}=q_min:(q_max-q_min)/q_segment:q_max;
object{4}=q_min:(q_max-q_min)/q_segment:q_max;
[num_data,month_database]=All_Combination(object);
sum_q=sum(month_database,2);
disp(['Min Monthly Discharge = ' num2str(min(sum_q))])
disp(['Max Monthly Discharge = ' num2str(max(sum_q))])
% Running Darab's GW FEM
dr_database=zeros(size(month_database,1),1);
for i=1:num_data
    if i<10
        nn='00';
    elseif i<100
        nn='0';
    else
        nn=[];
    end
    %%%%%%%%%%%%%%%%%%%%%%%%% GW FEM COMMAND %%%%%%%%%%%%%%%%%%%%%%%%
    dr=Darab_FEM(month_database(i,:),well_grid_1,well_grid_2,well_grid_3,well_grid_4,...
        num_well_region_1,num_well_region_2,num_well_region_3,num_well_region_4,...
        num_node,region_grid,river_grid,river_elev_grid,x,y,d,con_table,...
        con_table_i,con_table_j,kx_cell,ky_cell,q_bc_grid,elev_grid);
    dr_database(i)=sum(sum(dr))/sum(sum(region_grid));
    disp(['GW FEM Run # ' num2str(i) ' of ' num2str(num_data) ' ; mean dr= ' num2str(dr_database(i))])
    dr(region_grid==0)=0/0;
    figure(1);
    [c,h]=contourf(x,y,dr);
    clabel(c,h);
    ylabel('Y (m)');
    xlabel('X (m)');
    title(['Monthly Discharge ' num2str(sum(round(month_database(i,1:4)/1e6.*100)./100)) ...
        ' MCM , Mean Drawdown ' num2str(round(dr_database(i)*100)/100)]);
    saveas(figure(1),['Contour - ' nn num2str(i) '.png']);
    dr(region_grid==0)=0;
    figure(2)
    surf(x,y,dr)
    ylabel('Y (m)');
    xlabel('X (m)');
    zlabel('dr (m)');
    title(['Monthly Discharge ' num2str(sum(round(month_database(i,1:4)/1e6.*100)./100)) ...
        ' MCM , Mean Drawdown ' num2str(round(dr_database(i)*100)/100)]);
    saveas(figure(2),['3D - ' nn num2str(i) '.png']);
end
month_database=month_database./1e6;
save('Rudbal_FEM_Sequence_Run_Database.mat','month_database','dr_database',...
    'num_well_region_1','num_well_region_2','num_well_region_3','num_well_region_4');