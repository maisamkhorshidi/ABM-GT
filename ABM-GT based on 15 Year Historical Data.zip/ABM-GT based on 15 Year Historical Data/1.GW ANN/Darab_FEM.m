function dr=Darab_FEM(x1,well_grid_1,well_grid_2,well_grid_3,well_grid_4,...
    num_well_region_1,num_well_region_2,num_well_region_3,num_well_region_4,...
    num_node,region_grid,river_grid,river_elev_grid,x,y,d,con_table,...
    con_table_i,con_table_j,kx_cell,ky_cell,q_bc_grid,elev_grid)
q1=-x1(1)/num_well_region_1;
q2=-x1(2)/num_well_region_2;
q3=-x1(3)/num_well_region_3;
q4=-x1(4)/num_well_region_4;
% Determining Well Discharge of Grids
q_w_grid=zeros(size(x));
q_w_grid(well_grid_1==1)=q1;
q_w_grid(well_grid_2==1)=q2;
q_w_grid(well_grid_3==1)=q3;
q_w_grid(well_grid_4==1)=q4;
% FEM
% Determining Stiffness Matrix
k=zeros(sum(sum(region_grid)),sum(sum(region_grid)));
for i=1:size(con_table,1)
    k(con_table(i,1),con_table(i,1))=k(con_table(i,1),con_table(i,1))+...
        kx_cell(con_table_i(i,2),con_table_j(i,2))/3+ky_cell(con_table_i(i,2),con_table_j(i,2))/3;
    k(con_table(i,1),con_table(i,2))=k(con_table(i,1),con_table(i,2))-...
        kx_cell(con_table_i(i,2),con_table_j(i,2))/3+ky_cell(con_table_i(i,2),con_table_j(i,2))/6;
    k(con_table(i,1),con_table(i,3))=k(con_table(i,1),con_table(i,3))-...
        kx_cell(con_table_i(i,2),con_table_j(i,2))/6-ky_cell(con_table_i(i,2),con_table_j(i,2))/6;
    k(con_table(i,1),con_table(i,4))=k(con_table(i,1),con_table(i,4))+...
        kx_cell(con_table_i(i,2),con_table_j(i,2))/6-ky_cell(con_table_i(i,2),con_table_j(i,2))/3;
    k(con_table(i,2),con_table(i,1))=k(con_table(i,1),con_table(i,2));
    k(con_table(i,2),con_table(i,2))=k(con_table(i,2),con_table(i,2))+...
        kx_cell(con_table_i(i,2),con_table_j(i,2))/3+ky_cell(con_table_i(i,2),con_table_j(i,2))/3;
    k(con_table(i,2),con_table(i,3))=k(con_table(i,2),con_table(i,3))+...
        kx_cell(con_table_i(i,2),con_table_j(i,2))/6-ky_cell(con_table_i(i,2),con_table_j(i,2))/3;
    k(con_table(i,2),con_table(i,4))=k(con_table(i,2),con_table(i,4))-...
        kx_cell(con_table_i(i,2),con_table_j(i,2))/6-ky_cell(con_table_i(i,2),con_table_j(i,2))/6;
    k(con_table(i,3),con_table(i,1))=k(con_table(i,1),con_table(i,3));
    k(con_table(i,3),con_table(i,2))=k(con_table(i,2),con_table(i,3));
    k(con_table(i,3),con_table(i,3))=k(con_table(i,3),con_table(i,3))+...
        kx_cell(con_table_i(i,2),con_table_j(i,2))/3+ky_cell(con_table_i(i,2),con_table_j(i,2))/3;
    k(con_table(i,3),con_table(i,4))=k(con_table(i,3),con_table(i,4))-...
        kx_cell(con_table_i(i,2),con_table_j(i,2))/3+ky_cell(con_table_i(i,2),con_table_j(i,2))/6;
    k(con_table(i,4),con_table(i,1))=k(con_table(i,1),con_table(i,4));
    k(con_table(i,4),con_table(i,2))=k(con_table(i,2),con_table(i,4));
    k(con_table(i,4),con_table(i,3))=k(con_table(i,1),con_table(i,4));
    k(con_table(i,4),con_table(i,4))=k(con_table(i,4),con_table(i,4))+...
        kx_cell(con_table_i(i,2),con_table_j(i,2))/3+ky_cell(con_table_i(i,2),con_table_j(i,2))/3;
end
% Determining f
f=zeros(size(k,1),1);
for i=1:size(x,1)
    for j=1:size(x,2)
        if num_node(i,j)~=0
            f(num_node(i,j))=(q_w_grid(i,j)/(d^2*elev_grid(i,j)))*d^2/4;
        end
    end
end
% Determining q
q=zeros(size(k,1),1);
for i=1:size(x,1)
    for j=1:size(x,2)
        if num_node(i,j)~=0
            q(num_node(i,j))=q_bc_grid(i,j)/(elev_grid(i,j));
        end
    end
end
% Determining f+q
f_q=f+q;
% Imposing BC on k
k_modified=k;
f_q_modified=f_q;
for i=1:size(x,1)
    for j=1:size(x,2)
        if river_grid(i,j)~=0
            k_modified(:,num_node(i,j))=0;
            k_modified(num_node(i,j),:)=0;
            k_modified(num_node(i,j),num_node(i,j))=1;
        end
    end
end
% Imposing BC on f+q
for i=1:size(x,1)
    for j=1:size(y,2)
        if river_grid(i,j)~=0
            f_q_modified=f_q_modified-k(:,num_node(i,j)).*river_elev_grid(i,j);
        end
    end
end
for i=1:size(x,1)
    for j=1:size(y,2)
        if river_grid(i,j)~=0
            f_q_modified(num_node(i,j))=river_elev_grid(i,j);
        end
    end
end
% Solving the System
h=k_modified^(-1)*f_q_modified;
% Determining h at grids
h_grid=zeros(size(x));
for i=1:size(x,1)
    for j=1:size(x,2)
        if num_node(i,j)~=0
            h_grid(i,j)=h(num_node(i,j));
        end
    end
end
dr=elev_grid-h_grid;