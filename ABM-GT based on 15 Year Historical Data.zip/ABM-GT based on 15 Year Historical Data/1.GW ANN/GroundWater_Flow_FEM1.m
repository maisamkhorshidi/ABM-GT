clc
clear
tic
d=1000; % m
x_max=185000; % m
y_max=100000; % m
t=1; % month
% Sources and Sinks must be m^3/month
% Reading Excel File
kx_cell=xlsread('GroundWater Flow_FEM.xlsx','Kx'); % m/month
ky_cell=xlsread('GroundWater Flow_FEM.xlsx','Ky'); % m/month
h_guess_cell=xlsread('GroundWater Flow_FEM.xlsx','H0_Initial'); % m
q_bc_cell=xlsread('GroundWater Flow_FEM.xlsx','qx_BC'); % m/month
river_cell=xlsread('GroundWater Flow_FEM.xlsx','River');
q_w=xlsread('GroundWater Flow_FEM.xlsx','Wells','G2:G2000');
well_location=xlsread('GroundWater Flow_FEM.xlsx','Wells','I2:J2000');
obs_head=xlsread('GroundWater Flow_FEM.xlsx','Observation Wells','J2:J2000');
obs_well_location=xlsread('GroundWater Flow_FEM.xlsx','Observation Wells','H2:I2000');
elev_grid=xlsread('GroundWater Flow_FEM.xlsx','Elevation');
% Griding
x_grid=0:d:x_max;
y_grid=y_max:-d:0;
[x,y]=meshgrid(x_grid,y_grid);
% Region Cells
region_cell=h_guess_cell~=0;
% Boundary Cells
bound_cell=zeros(size(region_cell));
for i=1:size(bound_cell,1)
    for j=1:size(bound_cell,2)
        if i>1 && i<size(bound_cell,1)
            if j>1 && j<size(bound_cell,2)
                if region_cell(i-1,j)==0 || region_cell(i+1,j)==0 ||...
                        region_cell(i,j-1)==0 || region_cell(i,j+1)==0
                    if region_cell(i,j)==1
                        bound_cell(i,j)=1;
                    end
                end
            end
        end
    end
end
% Determining Region Grids
region_grid=zeros(size(x));
for i=1:size(region_cell,1)
    for j=1:size(region_cell,2)
        if region_cell(i,j)~=0
            region_grid(i,j)=1;
            region_grid(i+1,j)=1;
            region_grid(i,j+1)=1;
            region_grid(i+1,j+1)=1;
        end
    end
end
% Determining Boundary Grids
bound_grid=zeros(size(x));
for i=1:size(bound_grid,1)
    for j=1:size(bound_grid,2)
        if i>1 && i<size(bound_grid,1)
            if j>1 && j<size(bound_grid,2)
                if region_grid(i-1,j)==0 || region_grid(i+1,j)==0 ||...
                        region_grid(i,j-1)==0 || region_grid(i,j+1)==0
                    if region_grid(i,j)==1
                        bound_grid(i,j)=1;
                    end
                end
            end
        end
    end
end
% Determining River Grids
river_grid=zeros(size(x));
for i=1:size(river_cell,1)
    for j=1:size(river_cell,2)
        if river_cell(i,j)~=0
            river_grid(i,j)=1;
            river_grid(i+1,j)=1;
            river_grid(i,j+1)=1;
            river_grid(i+1,j+1)=1;
        end
    end
end
% Determining Wells' Grids
well_grid=zeros(size(x));
for i=1:size(well_location,1)
    well_grid(well_location(i,2)+1,well_location(i,1)+1)=1;
end
% Determining Well Grid Discharge
q_w_grid=zeros(size(x));
for i=1:size(well_location,1)
    q_w_grid(well_location(i,2)+1,well_location(i,1)+1)=q_w(i);
end
% Determining Observation Wells' Grids
obs_well_grid=zeros(size(x));
for i=1:size(obs_well_location,1)
    obs_well_grid(obs_well_location(i,1)+1,obs_well_location(i,2)+1)=1;
end
% Determining Observation Wells' Values at Grids
obs_head_grid=zeros(size(x));
for i=1:size(obs_well_location,1)
    obs_head_grid(obs_well_location(i,1)+1,obs_well_location(i,2)+1)=obs_head(i);
end
% Determining K Grid
kx_grid=zeros(size(x));
ky_grid=zeros(size(y));
for i=2:size(x,1)-1
    for j=2:size(y,2)-1
        if sum(region_cell(i-1,j-1)+region_cell(i-1,j)+region_cell(i,j-1)+region_cell(i,j))>0
            kx_grid(i,j)=sum(kx_cell(i-1,j-1)+kx_cell(i-1,j)+kx_cell(i,j-1)+kx_cell(i,j))./...
                sum(region_cell(i-1,j-1)+region_cell(i-1,j)+region_cell(i,j-1)+region_cell(i,j));
        end
        if sum(region_cell(i-1,j-1)+region_cell(i-1,j)+region_cell(i,j-1)+region_cell(i,j))>0
            ky_grid(i,j)=sum(ky_cell(i-1,j-1)+ky_cell(i-1,j)+ky_cell(i,j-1)+ky_cell(i,j))./...
                sum(region_cell(i-1,j-1)+region_cell(i-1,j)+region_cell(i,j-1)+region_cell(i,j));
        end
    end
end
% Determining Boundary Conditions' Value at Grids
q_bc_grid=zeros(size(x));
for i=2:size(x,1)-1
    for j=2:size(y,2)-1
        if bound_grid(i,j)==1
            q_bc_grid(i,j)=(q_bc_cell(i-1,j-1)+q_bc_cell(i,j-1)+q_bc_cell(i,j)+q_bc_cell(i-1,j))./...
                (bound_cell(i-1,j-1)+bound_cell(i,j-1)+bound_cell(i,j)+bound_cell(i-1,j));
        end        
    end
end
% h Guess Grid
h_guess_grid=zeros(size(x));
for i=2:size(x,1)-1
    for j=2:size(x,2)-1
        if region_cell(i-1,j-1)+region_cell(i,j-1)+region_cell(i-1,j)+...
                region_cell(i,j)~=0
            h_guess_grid(i,j)=(h_guess_cell(i-1,j-1)+h_guess_cell(i,j-1)+h_guess_cell(i-1,j)+...
                h_guess_cell(i,j))./(region_cell(i-1,j-1)+region_cell(i,j-1)+region_cell(i-1,j)+...
                region_cell(i,j));
        end
    end
end
% Determining Elevation of River at River Grids
river_elev_grid=river_grid.*elev_grid;
%% Finite Element Method
% Determining node numbers
num_node=zeros(size(x));
i_node=zeros(size(x));
j_node=zeros(size(x));
w=1;
for i=1:size(x,1)
    for j=1:size(x,2)
        if region_grid(i,j)==1
            num_node(i,j)=w;
            i_node(i,j)=i;
            j_node(i,j)=j;
            w=w+1;
        end
    end
end
% Determining Connectivity node table (Generating Rectangular Mesh)
con_table=zeros(numel(region_cell),4);
con_table_i=zeros(numel(region_cell),4);
con_table_j=zeros(numel(region_cell),4);
for i=1:size(x,1)-1
    for j=1:size(x,2)-1
        con_table((i-1)*size(x,2)+j,1)=num_node(i,j+1);
        con_table((i-1)*size(x,2)+j,2)=num_node(i,j);
        con_table((i-1)*size(x,2)+j,3)=num_node(i+1,j);
        con_table((i-1)*size(x,2)+j,4)=num_node(i+1,j+1);
        con_table_i((i-1)*size(x,2)+j,1)=i_node(i,j+1);
        con_table_i((i-1)*size(x,2)+j,2)=i_node(i,j);
        con_table_i((i-1)*size(x,2)+j,3)=i_node(i+1,j);
        con_table_i((i-1)*size(x,2)+j,4)=i_node(i+1,j+1);
        con_table_j((i-1)*size(x,2)+j,1)=j_node(i,j+1);
        con_table_j((i-1)*size(x,2)+j,2)=j_node(i,j);
        con_table_j((i-1)*size(x,2)+j,3)=j_node(i+1,j);
        con_table_j((i-1)*size(x,2)+j,4)=j_node(i+1,j+1);
    end
end
w=1;
for i=1:size(con_table,1)
    if sum(con_table(w,:)==0)>0
        con_table(w,:)=[];
        con_table_i(w,:)=[];
        con_table_j(w,:)=[];
    else
        w=w+1;
    end
end
% Determining Stiffness Matrix
k=zeros(sum(sum(region_grid)),sum(sum(region_grid)));
for i=1:size(con_table,1)
    k(con_table(i,1),con_table(i,1))=k(con_table(i,1),con_table(i,1))+...
        kx_cell(con_table_i(i,2),con_table_j(i,2))/3+ky_cell(con_table_i(i,2),con_table_j(i,2))/3;
    k(con_table(i,1),con_table(i,2))=k(con_table(i,1),con_table(i,2))-...
        kx_cell(con_table_i(i,2),con_table_j(i,2))/3+ky_cell(con_table_i(i,2),con_table_j(i,2))/6;
    k(con_table(i,1),con_table(i,3))=k(con_table(i,1),con_table(i,3))-...
        kx_cell(con_table_i(i,2),con_table_j(i,2))/6-ky_cell(con_table_i(i,2),con_table_j(i,2))/6;
    k(con_table(i,1),con_table(i,4))=k(con_table(i,1),con_table(i,4))+...
        kx_cell(con_table_i(i,2),con_table_j(i,2))/6-ky_cell(con_table_i(i,2),con_table_j(i,2))/3;
    k(con_table(i,2),con_table(i,1))=k(con_table(i,1),con_table(i,2));
    k(con_table(i,2),con_table(i,2))=k(con_table(i,2),con_table(i,2))+...
        kx_cell(con_table_i(i,2),con_table_j(i,2))/3+ky_cell(con_table_i(i,2),con_table_j(i,2))/3;
    k(con_table(i,2),con_table(i,3))=k(con_table(i,2),con_table(i,3))+...
        kx_cell(con_table_i(i,2),con_table_j(i,2))/6-ky_cell(con_table_i(i,2),con_table_j(i,2))/3;
    k(con_table(i,2),con_table(i,4))=k(con_table(i,2),con_table(i,4))-...
        kx_cell(con_table_i(i,2),con_table_j(i,2))/6-ky_cell(con_table_i(i,2),con_table_j(i,2))/6;
    k(con_table(i,3),con_table(i,1))=k(con_table(i,1),con_table(i,3));
    k(con_table(i,3),con_table(i,2))=k(con_table(i,2),con_table(i,3));
    k(con_table(i,3),con_table(i,3))=k(con_table(i,3),con_table(i,3))+...
        kx_cell(con_table_i(i,2),con_table_j(i,2))/3+ky_cell(con_table_i(i,2),con_table_j(i,2))/3;
    k(con_table(i,3),con_table(i,4))=k(con_table(i,3),con_table(i,4))-...
        kx_cell(con_table_i(i,2),con_table_j(i,2))/3+ky_cell(con_table_i(i,2),con_table_j(i,2))/6;
    k(con_table(i,4),con_table(i,1))=k(con_table(i,1),con_table(i,4));
    k(con_table(i,4),con_table(i,2))=k(con_table(i,2),con_table(i,4));
    k(con_table(i,4),con_table(i,3))=k(con_table(i,1),con_table(i,4));
    k(con_table(i,4),con_table(i,4))=k(con_table(i,4),con_table(i,4))+...
        kx_cell(con_table_i(i,2),con_table_j(i,2))/3+ky_cell(con_table_i(i,2),con_table_j(i,2))/3;
end
% Determining f
f=zeros(size(k,1),1);
for i=1:size(x,1)
    for j=1:size(x,2)
        if num_node(i,j)~=0
            f(num_node(i,j))=(q_w_grid(i,j)/(d^2*elev_grid(i,j)))*d^2/4;
        end
    end
end
% Determining q
q=zeros(size(k,1),1);
for i=1:size(x,1)
    for j=1:size(x,2)
        if num_node(i,j)~=0
            q(num_node(i,j))=q_bc_grid(i,j)/(elev_grid(i,j));
        end
    end
end
% Determining f+q
f_q=f+q;
% Imposing BC on k
k_modified=k;
f_q_modified=f_q;
for i=1:size(x,1)
    for j=1:size(x,2)
        if river_grid(i,j)~=0
            k_modified(:,num_node(i,j))=0;
            k_modified(num_node(i,j),:)=0;
            k_modified(num_node(i,j),num_node(i,j))=1;
        end
    end
end
% Imposing BC on f+q
for i=1:size(x,1)
    for j=1:size(y,2)
        if river_grid(i,j)~=0
            f_q_modified=f_q_modified-k(:,num_node(i,j)).*river_elev_grid(i,j);
        end
    end
end
for i=1:size(x,1)
    for j=1:size(y,2)
        if river_grid(i,j)~=0
            f_q_modified(num_node(i,j))=river_elev_grid(i,j);
        end
    end
end
% Solving the System
h=SolveLinearSystem(k_modified,f_q_modified);
% Determining h at grids
h_grid=zeros(size(x));
for i=1:size(x,1)
    for j=1:size(x,2)
        if num_node(i,j)~=0
            h_grid(i,j)=h(num_node(i,j));
        end
    end
end
% Plotting Figures
figure(1)
contourf(x,y,h_grid)
figure
surf(x,y,h_grid)
dr=elev_grid-h_grid;
figure
contourf(x,y,dr)
figure
surf(x,y,dr)

h_obs_cal=h_grid.*obs_well_grid;
save('Data_GW_Darab_FEM1.mat','x','y','con_table','num_node','i_node','j_node','obs_well_grid','obs_head_grid',...
    'region_grid','region_cell','q_w_grid','bound_grid','d','river_elev_grid','elev_grid','con_table_j',...
    'con_table_i','river_grid','q_bc_grid');
toc