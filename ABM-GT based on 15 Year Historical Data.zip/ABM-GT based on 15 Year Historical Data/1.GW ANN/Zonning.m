clc
clear
load Data_GW_Darab.mat
num_1=10;
zone_cell_k=zeros(100,190);
region_cell_1=[region_cell,zeros(100,5)];
w=0;
for i=1:size(zone_cell_k,1)/num_1
    for j=1:size(zone_cell_k,2)/num_1
        if sum(sum(region_cell_1((i-1)*num_1+1:i*num_1,(j-1)*num_1+1:j*num_1)))>=1
            w=w+1;
            zone_cell_k((i-1)*num_1+1:i*num_1,(j-1)*num_1+1:j*num_1)=w.*region_cell_1((i-1)*num_1+1:i*num_1,(j-1)*num_1+1:j*num_1);
        end
    end
end
region_cell_k=zone_cell_k(1:100,1:185);
save('region_cell_k.mat','region_cell_k')

num_2=11;
zone_bound_grid=zeros(110,187);
bound_grid_1=[bound_grid,zeros(101,1);zeros(9,187)];
w=0;
for i=1:size(zone_bound_grid,1)/num_2
    for j=1:size(zone_bound_grid,2)/num_2
        if sum(bound_grid_1((i-1)*num_2+1:i*num_2,(j-1)*num_2+1:j*num_2))>=1
            w=w+1;
            zone_bound_grid((i-1)*num_2+1:i*num_2,(j-1)*num_2+1:j*num_2)=w.*bound_grid_1((i-1)*num_2+1:i*num_2,(j-1)*num_2+1:j*num_2);
        end
    end
end
bound_grid_q=zone_bound_grid(1:101,1:186);
save('bound_grid_q.mat','bound_grid_q')
