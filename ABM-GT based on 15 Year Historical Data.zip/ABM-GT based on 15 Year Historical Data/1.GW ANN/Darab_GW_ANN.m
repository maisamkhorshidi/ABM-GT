clc
clear 
tic
load GW_database_ANN.mat
train_month_database=train_month_database';
train_dr_database=train_dr_database';
test_month_database=test_month_database';
test_dr_database=test_dr_database';
n=0;
for l=4:14
    for m=3:15
%         for h=10:15
            n=n+1;
            if n<10
                nn='00';
            elseif n<100
                nn='0';
            else
                nn=[];
            end
            net=newff(train_month_database,train_dr_database,[l,m],{'tansig','purelin'},'trainbr','learnh','mse',...
                {'fixunknowns','removeconstantrows','mapminmax'},{'removeconstantrows','mapminmax'});
            net=train(net,train_month_database,train_dr_database);
            Ytrain= sim(net,train_month_database);
            Ytes=sim(net,test_month_database);
            Ytest(:,:)=Ytes;
            e_test=test_dr_database-Ytes;
            SSE(n,1)=sse(e_test);
            e_train=train_dr_database-Ytrain;
            %% MARE Test
            nr_test=size(Ytest,1);
            ARE_test=zeros(nr_test,1);
            for i=1:nr_test
                ARE_test(i)=abs( e_test(i)/test_dr_database(i) );
            end
            MARE_test(n,1)=sum(ARE_test)/nr_test;
            %% MARE Target
            nr_train=size(Ytrain,1);
            ARE_train=zeros(nr_train,1);
            for i=1:nr_train
                ARE_train(i)=abs( e_train(i)/train_dr_database(i) );
            end
            MARE_train(n,1)=sum(ARE_train)/nr_train;
            %% R Squared test
            mean_test=sum(test_dr_database)/numel(test_dr_database);
            ss_tot=zeros(size(test_dr_database));
            ss_res=zeros(size(test_dr_database));
            for i=1:numel(test_dr_database)
                ss_tot(i)=(test_dr_database(i)-mean_test)^2;
                ss_res(i)=e_test(i)^2;
            end
            R_test(n,1)=1-sum(ss_res)/sum(ss_tot);
            %% R Squared test
            mean_train=sum(train_dr_database)/numel(train_dr_database);
            ss_tot=zeros(size(train_dr_database));
            for i=1:numel(train_dr_database)
                ss_tot(i)=(train_dr_database(i)-mean_train)^2;
                ss_res(i)=e_train(i)^2;
            end
            R_train(n,1)=1-sum(ss_res)/sum(ss_tot);
            % Plotting Figures
            figure(1)
            [rtrain,mtrain,btrain]=regression(train_dr_database,Ytrain);
            plotregression(train_dr_database,Ytrain);
            ylabel('Simulated Data of Train');
            xlabel('Observed Data of Train');
            title({'Simulation vs. Observation Data of Train';...
                ['l = ' num2str(l) ' , m = ' num2str(m)];...
                ['R = ' num2str(rtrain) ' , R^2 = ' num2str(R_train(n,1)) ...
                ' , MARE = ' num2str(MARE_train(n,1))]});
            saveas(figure(1),['Train - ' nn num2str(n) '.png']);
            figure(2)
            [rtest,mtest,btest]=regression(test_dr_database,Ytes);
            plotregression(test_dr_database,Ytes);
            ylabel('Simulated Data of Test');
            xlabel('Observed Data of Test');
            title({'Simulation vs. Observation Data of Test';...
                ['l = ' num2str(l) ' , m = ' num2str(m)];...
                ['R = ' num2str(rtest) ' , R^2 = ' num2str(R_test(n,1)) ...
                ' , MARE = ' num2str(MARE_test(n,1))]});
            saveas(figure(2),['Test - ' nn num2str(n) '.png']);
            MARE_TRAIN(n,1)=MARE_train(n,1);
            MARE_TEST(n,1)=MARE_test(n,1);
            R2_TRAIN(n,1)=R_train(n,1);
            R2_TEST(n,1)=R_test(n,1);
            R_TRAIN(n,1)=rtrain;
            R_TEST(n,1)=rtest;
            net_cell{n,1}=net;
            l_m(n,:)=[l,m];
            break_cell{n,1}=[];
            if MARE_test(n,1)<=0.05 && MARE_train(n,1)<=0.05 && R_test(n,1)>=0.94 && R_train(n,1)>=0.94
                disp(['break; l=' num2str(l) ' m=' num2str(m) ' MARE_test=' ...
                    num2str(MARE_test(n,1)) ' MARE_train=' num2str(MARE_train(n,1))...
                    ' R_test=' num2str(rtest) ' R_train=' num2str(rtrain)])
                break_cell{n,1}='Break';
            else
                disp(['l=' num2str(l) 'm=' num2str(m) ' MARE_test=' ...
                    num2str(MARE_test(n,1)) ' MARE_train=' num2str(MARE_train(n,1))...
                    ' R_test=' num2str(rtest) ' R_train=' num2str(rtrain)])
            end
%         end
    end 
end
save('GW_ANN_inf_cell.mat','MARE_TRAIN','MARE_TEST','R2_TRAIN','R2_TEST',...
    'R_TRAIN','R_TEST','net_cell','l_m','break_cell');
toc
% choose_net=2;
% MARE_test=MARE_TEST(choose_net);
% MARE_train=MARE_TRAIN(choose_net);
% l_m=l_m(choose_net,:);
% net=net_cell{choose_net};
% R_test=R_TEST(choose_net);
% R_train=R_TRAIN(choose_net);
% R2_test=R2_TEST(choose_net);
% R2_train=R2_TRAIN(choose_net);
% mean_test_dr_database=mean(test_dr_database);
% mean_train_dr_database=mean(train_dr_database);
% mean_test_month_database=mean(test_month_database);
% mean_train_month_database=mean(train_month_database);
% var_test_dr_database=var(test_dr_database);
% var_train_dr_database=var(train_dr_database);
% var_test_month_database=var(test_month_database);
% var_train_month_database=var(train_month_database);
% save('GW_Trained_net_ANN.mat','MARE_test','MARE_train','l_m','net','R_test',...
%     'R_train','R2_test','R2_train','mean_test_dr_database','mean_train_dr_database',...
%     'mean_test_month_database','mean_train_month_database','test_month_database',...
%     'train_month_database','test_dr_database','train_dr_database','var_test_dr_database','var_train_dr_database',...
%     'var_test_month_database','var_train_month_database');
% save('GW_net.mat','net');