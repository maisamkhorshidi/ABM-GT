function [num_combination,combination]=All_Combination(object)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%               MATLAB Code For All Combination of Objects                %
%                                                                         %
%     All_Combination.m :                                                 %
%                                                                         %
%   [combination,num_combination]=All_Combination(object)                 %
%                                                                         %
%   Input:                                                                %
%      object:                                                            %
%             A cell Structure whith 1 row. The number of colu-           %
%           mns is equal to number of places. Each element of             %
%           this cell must contain a row or column vector with            %
%           specified objects.                                            %
%                                                                         %
%   Output:                                                               %
%      num_combination:                                                   %
%             Number of all combinations (n*(n-1)*...*1).                 %
%                                                                         %
%      combination:                                                       %
%             A matrix Containing num_combination rows and num-           %
%           ber of its columns is equal to number of places. Each         %
%           row of this matrix is a unique combination of given           %
%           objects.                                                      %
%                                                                         %
%   Programmed By:                                                        %
%           Mohammad Sadegh (Maisam) Khorshidi Ali Kordi                  %
%            Completed & Tested on 25.10.95 (1.14.2017)                   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
num_object=zeros(1,numel(object));
for i=1:numel(num_object)
    num_object(i)=numel(object{i});
end
num_place=numel(object);
num_choice=1;
for i=1:num_place
    num_choice=num_choice*num_object(i);
end
num_combination=num_choice;
num_choice_place=zeros(1,num_place);
num_choice_place(1)=num_choice/num_object(1);
for i=2:num_place
    num_choice_place(i)=num_choice_place(i-1)/num_object(i);
end
combination=zeros(num_choice,num_place);
for i=1:num_choice
    for j=1:num_place
        combination(i,j)=object{j}( ceil(rem(ceil( i/num_choice_place(j) ),num_object(j)+1e-10))) ;
    end
end