clc
clear
load Rudbal_FEM_Sequence_Run_Database.mat
dominant_max=zeros(size(month_database,1),1);
for i=1:size(month_database,1)
    disp(['Dominant Max, Point # ' num2str(i)]) 
    domin=zeros(size(month_database,1),1);
    for j=1:size(month_database,1)
        if i==j
            continue
        end
        if sum(month_database(i,:)<=month_database(j,:))==size(month_database,2) && dr_database(i)<=dr_database(j)
            domin(j)=1;
        end
    end
    if sum(domin)>0
        dominant_max(i)=1;
    end
end
month_database=-month_database;
dr_database=-dr_database;
dominant_min=zeros(size(month_database,1),1);
for i=1:size(month_database,1)
    disp(['Dominant Min, Point # ' num2str(i)]) 
    domin=zeros(size(month_database,1),1);
    for j=1:size(month_database,1)
        if i==j
            continue
        end
        if sum(month_database(i,:)<=month_database(j,:))==size(month_database,2) && dr_database(i)<=dr_database(j)
            domin(j)=1;
        end
    end
    if sum(domin)>0
        dominant_min(i)=1;
    end
end
dominant=dominant_max.*dominant_min;
month_database=-month_database;
dr_database=-dr_database;
for h=1:1000
    disp(['Iteration # ' num2str(h)]) 
    test_data=randi([1,sum(dominant)],ceil(size(month_database,1)*0.3),1);
    for i=1:size(test_data,1)
        for j=1:size(test_data,1)
            if test_data(i)==test_data(j)
                test_data(j)=test_data(j)+1;
            end
        end
    end
    w=1;
    for i=1:size(test_data,1)
        if test_data(w)>size(month_database,1) || test_data(w)>sum(dominant)
            test_data(w)=[];
        else
            w=w+1;
        end
    end
    test_data=sort(test_data);
    train_data=zeros(size(month_database,1)-size(test_data,1),1);
    k=1;
    for i=1:size(month_database,1)
        if sum(i==test_data)>0
        else
            train_data(k)=i;
            k=k+1;
        end
    end
    test_month_database=zeros(size(test_data,1),size(month_database,2));
    test_dr_database=zeros(size(test_data,1),1);
    train_month_database=zeros(size(month_database,1)-size(test_data,1),size(month_database,2));
    train_dr_database=zeros(size(month_database,1)-size(test_data,1),1);
    for i=1:size(test_data,1)
        test_month_database(i,:)=month_database(test_data(i),:);
        test_dr_database(i,1)=dr_database(test_data(i),1);
    end
    for i=1:size(train_data,1)
        train_month_database(i,:)=month_database(train_data(i),:);
        train_dr_database(i,1)=dr_database(train_data(i),1);
    end
    mean_test_month_database=mean(test_month_database);
    mean_test_dr_database=mean(test_dr_database);
    mean_train_month_database=mean(train_month_database);
    mean_train_dr_database=mean(train_dr_database);
    var_test_month_database=var(test_month_database);
    var_test_dr_database=var(test_dr_database);
    var_train_month_database=var(train_month_database);
    var_train_dr_database=var(train_dr_database);
    tol_rel_mean_month_database=sum(abs(mean_test_month_database-mean_train_month_database)./max([mean_test_month_database;mean_train_month_database]))/size(month_database,2);
    tol_rel_mean_dr_database=sum(abs(mean_test_dr_database-mean_train_dr_database)./max([mean_test_dr_database;mean_train_dr_database]))/size(dr_database,2);
    tol_rel_var_month_database=sum(abs(var_test_month_database-var_train_month_database)./max([var_test_month_database;var_train_month_database]))/size(month_database,2);
    tol_rel_var_dr_database=sum(abs(var_test_dr_database-var_train_dr_database)./max([var_test_dr_database;var_train_dr_database]))/size(dr_database,2);
    if tol_rel_mean_month_database<=0.05 && tol_rel_mean_dr_database<=0.05 && tol_rel_var_month_database<=0.05 && tol_rel_var_dr_database<=0.05
        disp('break')
        save('GW_database_ANN.mat','train_month_database','train_dr_database','test_month_database','test_dr_database');
        break
    end
end