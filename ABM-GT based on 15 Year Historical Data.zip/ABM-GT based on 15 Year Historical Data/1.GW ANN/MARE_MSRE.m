clc
clear
dr_obs_calib=[];
dr_cal_calib=[];
for i=1:28
    dr_obs_calib=[dr_obs_calib;xlsread('Calibration-Verify-H.xlsx',num2str(i),'L2:L2000')];
    dr_cal_calib=[dr_cal_calib;xlsread('Calibration-Verify-H.xlsx',num2str(i),'M2:M2000')];
end
e_calib=dr_obs_calib-dr_cal_calib;
h_obs_verify=[];
h_cal_verify=[];
for i=29:40
    h_obs_verify=[h_obs_verify;xlsread('Calibration-Verify-H.xlsx',num2str(i),'L2:L2000')];
    h_cal_verify=[h_cal_verify;xlsread('Calibration-Verify-H.xlsx',num2str(i),'M2:M2000')];
end
e_verify=h_obs_verify-h_cal_verify;
%% MARE Verify
nr_verify=size(h_obs_verify,1);
ARE_verify=zeros(nr_verify,1);
for i=1:nr_verify
    if h_obs_verify(i)==0
        continue
    else
        ARE_verify(i)=abs( e_verify(i)/h_obs_verify(i) );
    end
end
MARE_verify=sum(ARE_verify)/nr_verify;
%% MARE Calibration
nr_calib=size(dr_obs_calib,1);
ARE_calib=zeros(nr_calib,1);
for i=1:nr_calib
    if dr_obs_calib(i)==0
        continue
    else
        ARE_calib(i)=abs( e_calib(i)/dr_obs_calib(i) );
    end
end
MARE_calib=sum(ARE_calib)/nr_calib;
%% R Squared Verify
mean_verify=sum(h_obs_verify)/numel(h_obs_verify);
ss_tot_verify=zeros(size(h_obs_verify));
ss_res_verify=zeros(size(h_obs_verify));
for i=1:numel(h_obs_verify)
    ss_tot_verify(i)=(h_obs_verify(i)-mean_verify)^2;
    ss_res_verify(i)=e_verify(i)^2;
end
R_verify=1-sum(ss_res_verify)/sum(ss_tot_verify);
%% R Squared Calibration
mean_calib=sum(dr_obs_calib)/numel(dr_obs_calib);
ss_tot_calib=zeros(size(dr_obs_calib));
ss_res_calib=zeros(size(dr_obs_calib));
for i=1:numel(dr_obs_calib)
    ss_tot_calib(i)=(dr_obs_calib(i)-mean_calib)^2;
    ss_res_calib(i)=e_calib(i)^2;
end
R_calib=1-sum(ss_res_calib)/sum(ss_tot_calib);
%%
figure(1);
% [mcalib,bcalib,rcalib]=postreg(dr_cal_calib,dr_obs_calib);

plotregression(dr_obs_calib,dr_cal_calib)
ylabel('Simulated Data of Calibration');
xlabel('Observed Data of Calibration')

figure(2);
% [mverify,bverify,rverify]=postreg(h_cal_verify,h_obs_verify);

plotregression(h_obs_verify,h_cal_verify)
ylabel('Simulated Data of Verification');
xlabel('Observed Data of Verification')
[rverify,mverify,bverify] = regression(h_obs_verify,h_cal_verify);
[rcalib,mcalib,bcalib] = regression(dr_obs_calib,dr_cal_calib);
%% MSE Verify
% h_cal_reg_verify=mverify.*h_obs_verify+bverify;
h_cal_reg_verify=h_obs_verify;
err_verify=h_cal_reg_verify-h_cal_verify;
MSE_verify=sum(err_verify.^2)./size(err_verify,1);
%% MSE calib
dr_cal_reg_calib=dr_obs_calib;
err_calib=dr_cal_reg_calib-dr_cal_calib;
MSE_calib=sum(err_calib.^2)./size(err_calib,1);
save('MSRE_MARE.mat','MARE_verify','MARE_calib','R_calib','R_verify','MSE_calib','MSE_verify');