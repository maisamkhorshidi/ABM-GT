function z=Darab_Calibration_FEM_fcn(x1)
global x y con_table num_node i_node j_node obs_well_grid obs_head_grid region_grid
global region_cell region_cell_k q_w_grid d river_elev_grid elev_grid con_table_j
global con_table_i river_grid t population bound_grid_q
t=t+1;
if rem(t,population)==0
    a=1;
else
    a=rem(t,population);
end
kx=x1(1:max(max(region_grid_k)));
ky=x1(max(max(region_grid_k))+1:2*max(max(region_grid_k)));
qz=x1(2*max(max(region_grid_k))+1:3*max(max(region_grid_k)));
qx=x1(3*max(max(region_grid_k))+1:3*max(max(region_grid_k))+max(max(bound_grid_q)));
qy=x1(3*max(max(region_grid_k))+max(max(bound_grid_q))+1:end);
kx_grid=zeros(size(region_cell_k));
ky_grid=zeros(size(region_cell_k));
qz_grid=zeros(size(region_cell_k));
for i=1:numel(kx)
    kx_grid(region_cell_k==i)=kx(i);
    ky_grid(region_cell_k==i)=ky(i);
    qz_grid(region_cell_k==i)=qz(i);
end
qx_grid=zeros(size(region_grid));
qy_grid=zeros(size(region_grid));
for i=1:numel(qx)
    qx_grid(bound_grid_q==i)=qx(i);
    qy_grid(bound_grid_q==i)=qy(i);
end
% Determining Stiffness Matrix
k=zeros(sum(sum(region_grid)),sum(sum(region_grid)));
for i=1:size(con_table,1)
    k(con_table(i,1),con_table(i,1))=k(con_table(i,1),con_table(i,1))+...
        kx_cell(con_table_i(i,2),con_table_j(i,2))/3+ky_cell(con_table_i(i,2),con_table_j(i,2))/3;
    k(con_table(i,1),con_table(i,2))=k(con_table(i,1),con_table(i,2))-...
        kx_cell(con_table_i(i,2),con_table_j(i,2))/3+ky_cell(con_table_i(i,2),con_table_j(i,2))/6;
    k(con_table(i,1),con_table(i,3))=k(con_table(i,1),con_table(i,3))-...
        kx_cell(con_table_i(i,2),con_table_j(i,2))/6-ky_cell(con_table_i(i,2),con_table_j(i,2))/6;
    k(con_table(i,1),con_table(i,4))=k(con_table(i,1),con_table(i,4))+...
        kx_cell(con_table_i(i,2),con_table_j(i,2))/6-ky_cell(con_table_i(i,2),con_table_j(i,2))/3;
    k(con_table(i,2),con_table(i,1))=k(con_table(i,1),con_table(i,2));
    k(con_table(i,2),con_table(i,2))=k(con_table(i,2),con_table(i,2))+...
        kx_cell(con_table_i(i,2),con_table_j(i,2))/3+ky_cell(con_table_i(i,2),con_table_j(i,2))/3;
    k(con_table(i,2),con_table(i,3))=k(con_table(i,2),con_table(i,3))+...
        kx_cell(con_table_i(i,2),con_table_j(i,2))/6-ky_cell(con_table_i(i,2),con_table_j(i,2))/3;
    k(con_table(i,2),con_table(i,4))=k(con_table(i,2),con_table(i,4))-...
        kx_cell(con_table_i(i,2),con_table_j(i,2))/6-ky_cell(con_table_i(i,2),con_table_j(i,2))/6;
    k(con_table(i,3),con_table(i,1))=k(con_table(i,1),con_table(i,3));
    k(con_table(i,3),con_table(i,2))=k(con_table(i,2),con_table(i,3));
    k(con_table(i,3),con_table(i,3))=k(con_table(i,3),con_table(i,3))+...
        kx_cell(con_table_i(i,2),con_table_j(i,2))/3+ky_cell(con_table_i(i,2),con_table_j(i,2))/3;
    k(con_table(i,3),con_table(i,4))=k(con_table(i,3),con_table(i,4))-...
        kx_cell(con_table_i(i,2),con_table_j(i,2))/3+ky_cell(con_table_i(i,2),con_table_j(i,2))/6;
    k(con_table(i,4),con_table(i,1))=k(con_table(i,1),con_table(i,4));
    k(con_table(i,4),con_table(i,2))=k(con_table(i,2),con_table(i,4));
    k(con_table(i,4),con_table(i,3))=k(con_table(i,1),con_table(i,4));
    k(con_table(i,4),con_table(i,4))=k(con_table(i,4),con_table(i,4))+...
        kx_cell(con_table_i(i,2),con_table_j(i,2))/3+ky_cell(con_table_i(i,2),con_table_j(i,2))/3;
end
% Determining f
f=zeros(size(k,1),1);
for i=1:size(x,1)
    for j=1:size(x,2)
        if num_node(i,j)~=0
            f(num_node(i,j))=(q_w_grid(i,j)/(d^2*elev_grid(i,j)))*d^2/4;
        end
    end
end
% Determining q
q=zeros(size(k,1),1);
for i=1:size(x,1)
    for j=1:size(x,2)
        if num_node(i,j)~=0
            q(num_node(i,j))=q_bc_grid(i,j)/(d*elev_grid(i,j));
        end
    end
end
% Determining f+q
f_q=f+q;
% Imposing BC on k
k_modified=k;
f_q_modified=f_q;
for i=1:size(x,1)
    for j=1:size(x,2)
        if river_grid(i,j)~=0
            k_modified(:,num_node(i,j))=0;
            k_modified(num_node(i,j),:)=0;
            k_modified(num_node(i,j),num_node(i,j))=1;
        end
    end
end
% Imposing BC on f+q
for i=1:size(x,1)
    for j=1:size(y,2)
        if river_grid(i,j)~=0
            f_q_modified=f_q_modified-k(:,num_node(i,j)).*river_elev_grid(i,j);
        end
    end
end
for i=1:size(x,1)
    for j=1:size(y,2)
        if river_grid(i,j)~=0
            f_q_modified(num_node(i,j))=river_elev_grid(i,j);
        end
    end
end
% Solving the System
h=k_modified^(-1)*f_q_modified;
% Determining h at grids
h_grid=zeros(size(x));
for i=1:size(x,1)
    for j=1:size(x,2)
        if num_node(i,j)~=0
            h_grid(i,j)=h(num_node(i,j));
        end
    end
end
h_obs_cal=h_grid.*obs_well_grid;
z=sum(sum(abs(h_obs_cal-obs_head_grid)));
% disp([num2str(a) '    ' num2str(z)])