clc
clear
global x y con_table num_node i_node j_node elev_grid H0_grid con_table_i
global region_grid region_cell q_w_grid bound_grid d river_elev_grid river_grid
global bound_grid_q region_cell_k obs_well_grid obs_head_grid con_table_j t
t=0;
load Data_GW_Darab.mat
load bound_grid_q.mat
load region_cell_k.mat
region_cell_k=region_cell;
num_var=2*max(max(region_cell_k))+max(max(bound_grid_q));
population=1*num_var;
Generations=1000;
IntCon=[];
lb=[0,0,-inf.*ones(1,num_var-2)];
ub=[];
options = gaoptimset('Display','iter',...
        'PopulationSize',population,'Generations',Generations,'StallGenLimit',50);
[variables,fval,exitflag,output,final_pop]=ga(@Darab_GW_FEM,num_var,[],[],[],[],...
    lb,ub,[],IntCon,options);