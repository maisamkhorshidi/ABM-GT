clc
clear
global x y con_table num_node i_node j_node obs_well_grid obs_head_grid region_grid
global region_cell region_cell_k q_w_grid d river_elev_grid elev_grid con_table_j
global con_table_i river_grid t population bound_grid_q
t=0;
load Data_GW_Darab_FEM.mat
load bound_grid_q.mat
load region_cell_k.mat
bound_grid_q=(bound_grid_q>0).*1;
region_grid_k=(region_grid_k>0).*1;
num_var=3*max(max(region_grid_k))+2*max(max(bound_grid_q));
population=1*num_var;
Generations=50;
IntCon=[];
lb=[zeros(1,num_var-2*max(max(bound_grid_q))),-inf.*ones(1,2*max(max(bound_grid_q)))];
ub=[];
options = gaoptimset('Display','iter','PlotFcns',@gaplotbestf,...
        'PopulationSize',population,'Generations',Generations,'StallGenLimit',50);
[x1,fval,exitflag,output,final_pop]=ga(@Darab_Calibration_FEM_fcn,num_var,[],[],[],[],...
    lb,ub,[],IntCon,options);
[kx_grid,ky_grid,qx_grid,qy_grid,qz_grid,abs_diff]=Darab_GW_FEM_Calculation(x1);
save('Darab_GW_Calibration_FEM.mat','kx_grid','ky_grid','qx_grid','qy_grid','qz_grid',...
    'x','y','obs_well_grid','obs_head_grid','h_guess_grid','river_grid',...
    'region_grid_k','bound_grid_q','final_pop','x1');