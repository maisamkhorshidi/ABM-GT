function z=Darab_GW_FEM(x1)
global x y obs_well_grid obs_head_grid h_guess_grid river_grid t  region_grid_k bound_grid_q
global region_grid region_cell q_w_grid bound_grid d river_elev_grid elev_grid H0_grid population
t=t+1;
if rem(t,population)==0
    a=1;
else
    a=rem(t,population);
end
num_iter=200;
epsilon=0.05;
kx=x1(1:max(max(region_grid_k)));
ky=x1(max(max(region_grid_k))+1:2*max(max(region_grid_k)));
qz=x1(2*max(max(region_grid_k))+1:3*max(max(region_grid_k)));
qx=x1(3*max(max(region_grid_k))+1:3*max(max(region_grid_k))+max(max(bound_grid_q)));
qy=x1(3*max(max(region_grid_k))+max(max(bound_grid_q))+1:end);
kx_grid=zeros(size(region_grid));
ky_grid=zeros(size(region_grid));
qz_grid=zeros(size(region_grid));
for i=1:numel(kx)
    kx_grid(region_grid_k==i)=kx(i);
    ky_grid(region_grid_k==i)=ky(i);
    qz_grid(region_grid_k==i)=qz(i);
end
qx_grid=zeros(size(region_grid));
qy_grid=zeros(size(region_grid));
for i=1:numel(qx)
    qx_grid(bound_grid_q==i)=qx(i);
    qy_grid(bound_grid_q==i)=qy(i);
end
h=cell(num_iter,1);
h{1}=h_guess_grid;
w=0;
for iter=2:num_iter
%     disp(['Iteration # ' num2str(iter) ' of ' num2str(num_iter)])
    h{iter}=zeros(size(x));
    for jj=2:size(x,1)-1
        j=size(x,1)-jj+1;
        for i=2:size(x,2)-1
            if bound_grid(j,i)==1
                if (region_cell(j,i-1)==0 && region_cell(j-1,i-1)==0 && region_cell(j,i)==0 && region_cell(j-1,i)==1) ||...
                        (region_cell(j,i-1)==1 && region_cell(j-1,i-1)==0 && region_cell(j,i)==0 && region_cell(j-1,i)==1)
                    h{iter}(j,i)=(d^2./(2*kx_grid(j,i)+2*ky_grid(j,i))).*...
                        (kx_grid(j,i)./d^2.*h{iter-1}(j,i+1)+ky_grid(j,i)./d^2.*h{iter-1}(j-1,i)-...
                        ((qx_grid(j,i)-qy_grid(j,i))./(d^2*elev_grid(j,i)))+(q_w_grid(j,i)+qz_grid(j,i))/(d^2*elev_grid(j,i)));
                elseif (region_cell(j,i-1)==0 && region_cell(j-1,i-1)==0 && region_cell(j,i)==1 && region_cell(j-1,i)==1)
                    h{iter}(j,i)=(d^2./(kx_grid(j,i)+2*ky_grid(j,i))).*(kx_grid(j,i)./d^2.*h{iter-1}(j,i+1)+...
                        ky_grid(j,i)./d^2.*(h{iter-1}(j+1,i)+h{iter-1}(j-1,i))-qx_grid(j,i)./(d^2*elev_grid(j,i))+(q_w_grid(j,i)+qz_grid(j,i))/(d^2*elev_grid(j,i)));
                elseif (region_cell(j,i-1)==0 && region_cell(j-1,i-1)==1 && region_cell(j,i)==0 && region_cell(j-1,i)==1)
                    h{iter}(j,i)=(d^2./(2*kx_grid(j,i)+ky_grid(j,i))).*(kx_grid(j,i)./d^2.*(h{iter-1}(j,i+1)+...
                        h{iter-1}(j,i-1))-ky_grid(j,i)./d^2.*h{iter-1}(j-1,i)-qy_grid(j,i)./(d^2*elev_grid(j,i))+(q_w_grid(j,i)+qz_grid(j,i))/(d^2*elev_grid(j,i)));
                elseif (region_cell(j,i-1)==0 && region_cell(j-1,i-1)==1 && region_cell(j,i)==0 && region_cell(j-1,i)==0) ||...
                        (region_cell(j,i-1)==0 && region_cell(j-1,i-1)==1 && region_cell(j,i)==1 && region_cell(j-1,i)==0)
                    h{iter}(j,i)=(d^2./(kx_grid(j,i)+ky_grid(j,i))).*(kx_grid(j,i)./d^2*h{iter-1}(j,i-1)+...
                        ky_grid(j,i)./d^2*h{iter-1}(j-1,i)+((qx_grid(j,i)+qy_grid(j,i))/(d^2*elev_grid(j,i)))+(q_w_grid(j,i)+qz_grid(j,i))/(d^2*elev_grid(j,i)));
                elseif (region_cell(j,i-1)==1 && region_cell(j-1,i-1)==1 && region_cell(j,i)==0 && region_cell(j-1,i)==0)
                    h{iter}(j,i)=(d^2./(kx_grid(j,i)+2*ky_grid(j,i))).*(kx_grid(j,i)/d^2.*h{iter-1}(j,i-1)+...
                        ky_grid(j,i)/d^2.*(h{iter-1}(j+1,i)+h{iter-1}(j-1,i))+qx_grid(j,i)/(d^2*elev_grid(j,i))+(q_w_grid(j,i)+qz_grid(j,i))/(d^2*elev_grid(j,i)));
                elseif (region_cell(j,i-1)==0 && region_cell(j-1,i-1)==1 && region_cell(j,i)==0 && region_cell(j-1,i)==1)
                    h{iter}(j,i)=(d^2./(2*kx_grid(j,i)+ky_grid(j,i))).*(kx_grid(j,i)./d^2*(h{iter-1}(j,i+1)+...
                        h{iter-1}(j,i-1))+ky_grid(j,i)/d^2*h{iter-1}(j-1,i)+qy_grid(j,i)/(d^2*elev_grid(j,i))+(q_w_grid(j,i)+qz_grid(j,i))/(d^2*elev_grid(j,i)));
                elseif (region_cell(j,i-1)==1 && region_cell(j-1,i-1)==0 && region_cell(j,i)==0 && region_cell(j-1,i)==0) ||...
                        (region_cell(j,i-1)==1 && region_cell(j-1,i-1)==0 && region_cell(j,i)==0 && region_cell(j-1,i)==1)
                    h{iter}(j,i)=(d^2./(kx_grid(j,i)+ky_grid(j,i))).*(kx_grid(j,i)/d^2*h{iter-1}(j,i-1)+...
                        ky_grid(j,i)/d^2*h{iter-1}(j+1,i)+(qx_grid(j,i)-qy_grid(j,i))/(d^2*elev_grid(j,i))+(q_w_grid(j,i)+qz_grid(j,i))/(d^2*elev_grid(j,i)));
                elseif (region_cell(j,i-1)==1 && region_cell(j-1,i-1)==1 && region_cell(j,i)==0 && region_cell(j-1,i)==0)
                    h{iter}(j,i)=(d^2./(kx_grid(j,i)+2*ky_grid(j,i))).*(kx_grid(j,i)/d^2*h{iter-1}(j,i-1)+...
                        ky_grid(j,i)/d^2*(h{iter-1}(j-1,i)+h{iter-1}(j+1,i))+qx_grid(j,i)/(d^2*elev_grid(j,i))+(q_w_grid(j,i)+qz_grid(j,i))/(d^2*elev_grid(j,i)));
                elseif (region_cell(j,i-1)==1 && region_cell(j-1,i-1)==0 && region_cell(j,i)==1 && region_cell(j-1,i)==0)
                    h{iter}(j,i)=(d^2./(2*kx_grid(j,i)+ky_grid(j,i))).*(kx_grid(j,i)/d^2*(h{iter-1}(j,i+1)+...
                        h{iter-1}(j,i-1))+ky_grid(j,i)/d^2*h{iter-1}(j+1,i)-qy_grid(j,i)/(d^2*elev_grid(j,i))+(q_w_grid(j,i)+qz_grid(j,i))/(d^2*elev_grid(j,i)));
                elseif (region_cell(j,i-1)==0 && region_cell(j-1,i-1)==0 && region_cell(j,i)==1 && region_cell(j-1,i)==0) ||...
                        (region_cell(j,i-1)==0 && region_cell(j-1,i-1)==1 && region_cell(j,i)==1 && region_cell(j-1,i)==0)
                    h{iter}(j,i)=(d^2./(kx_grid(j,i)+ky_grid(j,i))).*(kx_grid(j,i)/d^2*h{iter-1}(j,i+1)+...
                        ky_grid(j,i)/d^2*h{iter-1}(j+1,i)-(qx_grid(j,i)+qy_grid(j,i))/(d^2*elev_grid(j,i))+(q_w_grid(j,i)+qz_grid(j,i))/(d^2*elev_grid(j,i)));
                elseif (region_cell(j,i-1)==0 && region_cell(j-1,i-1)==0 && region_cell(j,i)==1 && region_cell(j-1,i)==0)
                    h{iter}(j,i)=(d^2./(kx_grid(j,i)+2*ky_grid(j,i))).*(kx_grid(j,i)/d^2*h{iter-1}(j,i+1)+...
                        ky_grid(j,i)/d^2*(h{iter-1}(j+1,i)+h{iter-1}(j-1,i))-qx_grid(j,i)/(d^2*elev_grid(j,i))+(q_w_grid(j,i)+qz_grid(j,i))/(d^2*elev_grid(j,i)));
                elseif (region_cell(j,i-1)==0 && region_cell(j-1,i-1)==0 && region_cell(j,i)==1 && region_cell(j-1,i)==0)
                    h{iter}(j,i)=(d^2./(2*kx_grid(j,i)+ky_grid(j,i))).*(kx_grid(j,i)/d^2*(h{iter-1}(j,i-1)+...
                        h{iter-1}(j,i+1))+ky_grid(j,i)/d^2*h{iter-1}(j+1,i)-qy_grid(j,i)/(d^2*elev_grid(j,i))+(q_w_grid(j,i)+qz_grid(j,i))/(d^2*elev_grid(j,i)));
                else
                    w=w+1;
                end
            elseif bound_grid(j,i)==0 && region_grid(j,i)==1 && river_grid(j,i)==0
                h{iter}(j,i)=(q_w_grid(j,i)+qz_grid(j,i))/(d^2*elev_grid(j,i)).*(d^2./(2*kx_grid(j,i)+2*ky_grid(j,i)))+...
                    1./(2*kx_grid(j,i)+2*ky_grid(j,i)).*(ky_grid(j,i)*(h{iter-1}(j+1,i)+h{iter-1}(j-1,i))+...
                    kx_grid(j,i)*(h{iter-1}(j,i+1)+h{iter-1}(j,i-1)));
            elseif bound_grid(j,i)==0 && region_grid(j,i)==1 && river_grid(j,i)==1
                h{iter}(j,i)=river_elev_grid(j,i);
            end
        end
    end
    tol=max(max(abs(h{iter}-h{iter-1})))/(sum(sum(abs(h{iter})))/sum(sum(h{iter}~=0)));
    if tol<epsilon
%         disp('Stopping Criteria has been met, Stop Iteration')
        break
    end
end
h(iter+1:end)=[];
h_obs_cal=h{end}.*obs_well_grid;
z=sum(sum(abs(h_obs_cal-obs_head_grid)));
% disp([num2str(a) '    ' num2str(z)])