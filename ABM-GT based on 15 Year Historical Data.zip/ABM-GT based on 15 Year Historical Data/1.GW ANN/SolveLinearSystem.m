function x=SolveLinearSystem(A,b)
for i=1:size(A,2)-1
    c=zeros(size(b));
    c(1:i)=1;
    c(i+1:end)=-A(i,i)./A(i+1:end,i);
    b=c.*b;
    c=repmat(c,1,size(A,2));
    A=c.*A;
    for j=i+1:size(A,1)
        A(j,:)=A(i,:)+A(j,:);
        b(j)=b(i)+b(j);
    end
end
for k=1:size(A,2)-1
    i=size(A,2)-k+1;
    c=zeros(size(b));
    c(i:end)=1;
    c(1:i-1)=-A(i,i)./A(1:i-1,i);
    b=c.*b;
    c=repmat(c,1,size(A,2));
    A=c.*A;
    for j=1:i-1
        A(j,:)=A(i,:)+A(j,:);
        b(j)=b(i)+b(j);
    end
end
for i=1:size(A,1)
    b(i)=b(i)./A(i,i);
    A(i,i)=A(i,i)./A(i,i);
end
x=b;