function [max_vote_plu,fval_plurality,Plurality_Choice]=...
    Plurality_Choice_Rule_General(fval)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   MATLAB Code For Social Choice Procedure (Plurality Choice Rule)       %
%                                                                         %
%     Plurality_Choice_Rule_General.m :                                   %
%                                                                         %
%   [max_vote_plu,fval_plurality,Plurality_Choice]=...                    %
%   Plurality_Choice_Rule(fval)                                           %
%                                                                         %
%   Input:                                                                %
%      fval:                                                              %
%             A matrix which contains the objective values of each        %
%           stratey. The number of strategies is equal to fval's          %
%           rows and the number of objectives is equal to fval's          %
%           columns.                                                      %
%                                                                         %
%   Output:                                                               %
%      max_vote_plu:                                                      %
%             Number of times the best strategy gained vote from          %
%           voters.                                                       %
%      fval_plurality:                                                    %
%             Values of the strategy which gained maximum vote.           %
%      Plurality_Choice:                                                  %
%             Number of strategy which gained maximum vote.               %
%           strategies.                                                   %
%                                                                         %
%   Programmed By:                                                        %
%           Mohammad Sadegh (Maisam) Khorshidi Ali Kordi                  %
%            Completed & Tested on 24.11.94 (2.13.2016)                   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
z_fval=cell(size(fval,2),1);
z_sort=cell(size(fval,2),1);
for i=1:size(fval,2)
    z_fval{i}=[zeros(size(fval,1),1) fval];
    z_sort{i}=[];
    for j=1:size(fval,1)
        z_fval{i}(j,1)=j;
    end
end
for j=1:size(fval,2)
    for i=1:size(fval,1)
        [r,~]=find(z_fval{j}(:,j+1)==min(z_fval{j}(:,j+1)));
        z_sort{j}=[z_sort{j};z_fval{j}(r(1),:)];
        z_fval{j}(r(1),:)=[];
    end
end
z_num=zeros(size(fval));
for i=1:size(fval,2)
    z_num(:,i)=z_sort{i}(:,1);
end
clear histogram
histogram=hist(z_num(1,:),1:size(fval,1));
max_vote_plu=max(histogram);
Plurality_Choice=find(histogram==max_vote_plu);
fval_plurality=fval(Plurality_Choice,:);