function [win_Con,los_Con,prefer_Con,fval_Con,Con_Choice]=...
    Condorcet_Choice_General(fval)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   MATLAB Code For Social Choice Procedure (Condorcet Choice)            %
%                                                                         %
%     Condorcet_Choice_General.m :                                        %
%                                                                         %
%   [win_Con,los_Con,prefer_Con,fval_Con,num_z_Con]=...                   %
%     Condorcet_Choice_General(fval)                                      %
%                                                                         %
%   Input:                                                                %
%      fval:                                                              %
%             A matrix which contains the objective values of each        %
%           stratey. The number of strategies is equal to fval's          %
%           rows and the number of objectives is equal to fval's          %
%           columns.                                                      %
%                                                                         %
%   Output:                                                               %
%      win_Con:                                                           %
%             Number of times when a strategy won over all                %
%           other strategies.                                             %
%      los_Con:                                                           %
%             Number of times when a strategy lost to all other           %
%           strategies.                                                   %
%      prefer_Con:                                                        %
%             Number of times when a strategy preferred to other          %
%           strategies.                                                   %
%      fval_Con:                                                          %
%             Number of the strategy which has the best record of         %
%           winning and preferring over the other strategies.             %
%      Con_Choice:                                                        %
%             Number of strategy which selected by Condorcet Choice       %
%           as the best Solution.                                         %
%                                                                         %
%   Programmed By:                                                        %
%           Mohammad Sadegh (Maisam) Khorshidi Ali Kordi                  %
%            Completed & Tested on 22.11.94 (2.11.2016)                   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
z_fval=cell(size(fval,2),1);
z_sort=cell(size(fval,2),1);
for i=1:size(fval,2)
    z_fval{i}=[zeros(size(fval,1),1) fval];
    z_sort{i}=[];
    for j=1:size(fval,1)
        z_fval{i}(j,1)=j;
    end
end
for j=1:size(fval,2)
    for i=1:size(fval,1)
        [r,~]=find(z_fval{j}(:,j+1)==min(z_fval{j}(:,j+1)));
        z_sort{j}=[z_sort{j};z_fval{j}(r(1),:)];
        z_fval{j}(r(1),:)=[];
    end
end
z_num=zeros(size(fval));
for i=1:size(fval,2)
    z_num(:,i)=z_sort{i}(:,1);
end
comp_mat_win=zeros(size(fval,1),size(fval,1));
comp_mat_los=zeros(size(fval,1),size(fval,1));
win_Con=zeros(size(fval,1),1);
los_Con=zeros(size(fval,1),1);
for k=1:size(fval,2)
    for i=1:size(fval,1)
        for j=1:size(fval,1)
            [ri,~]=find(z_num(:,k)==i);
            [rj,~]=find(z_num(:,k)==j);
            if ri<rj
                comp_mat_win(i,j)=comp_mat_win(i,j)+1;
            elseif ri>rj
                comp_mat_los(i,j)=comp_mat_los(i,j)+1;
            end
        end
    end
end
for i=1:size(fval,1)
    for j=1:size(fval,1)
        if comp_mat_win(i,j)>comp_mat_los(i,j)
            win_Con(i,1)=win_Con(i,1)+1;
        else
            los_Con(i,1)=los_Con(i,1)+1;
        end
    end
end
prefer_Con=sum(comp_mat_win,2);
[rw,~]=find(win_Con==max(win_Con));
Con_Choice=zeros(numel(find(prefer_Con==max(prefer_Con(rw,1)))),1);
j=1;
for i=1:size(fval,1)
    if prefer_Con(i,1)==max(prefer_Con(rw,1))
        Con_Choice(j,1)=i;
        j=j+1;
    end
end
fval_Con=fval(Con_Choice,:);