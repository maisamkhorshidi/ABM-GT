function [Score,sum_Score,fval_Borda,Borda_Choice]=...
    Borda_Scoring_General(fval)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   MATLAB Code For Social Choice Procedure (Borda Scoring)               %
%                                                                         %
%     Borda_Scoring_General.m :                                           %
%                                                                         %
%   [Score,sum_Score,fval_Borda,num_fval_borda]=...                       %
%    Borda_Scoring_General(fval)                                          %
%                                                                         %
%   Input:                                                                %
%      fval:                                                              %
%             A matrix which contains the objective values of each        %
%           stratey. The number of strategies is equal to fval's          %
%           rows and the number of objectives is equal to fval's          %
%           columns.                                                      %
%                                                                         %
%   Output:                                                               %
%      Score:                                                             %
%             A matrix with the size of FVAL which contains the           %
%           score assigned to each strategy by every agent.               %
%      sum_Score:                                                         %
%             Sum of the assigned scores to each strategy.                %
%      fval_Borda:                                                        %
%             Values of strategy which has the best score.                %
%      num_fval_Borda:                                                    %
%             Number of the strategy which has the best total             %
%           score.                                                        %
%                                                                         %
%   Programmed By:                                                        %
%           Mohammad Sadegh (Maisam) Khorshidi Ali Kordi                  %
%            Completed & Tested on 22.11.94 (2.11.2016)                   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Z_bor=cell(size(fval,2),1);
Score=zeros(size(fval));
for i=1:size(fval,2)
    Z_bor{i}=sort(fval(:,i),'descend');
end
for j=1:size(fval,2)
    for i=1:size(fval,1)
        if i>=2 && Z_bor{j}(i)==Z_bor{j}(i-1)
        else
            Score(:,j)=Score(:,j)+(fval(:,j)==Z_bor{j}(i)).*i;
        end
    end
end
sum_Score=sum(Score,2);
[Borda_Choice,~]=find(sum_Score==max(sum_Score));
if numel(Borda_Choice)>size(fval,2)
    Borda_Choice=Borda_Choice(1:size(fval,2));
end
fval_Borda=fval(Borda_Choice,:);