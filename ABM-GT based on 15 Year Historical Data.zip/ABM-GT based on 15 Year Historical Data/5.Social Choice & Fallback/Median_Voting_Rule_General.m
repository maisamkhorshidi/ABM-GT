function [max_vote_mvr,fval_mvr,MVR_Choice]=Median_Voting_Rule_General(fval)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   MATLAB Code For Social Choice Procedure (Median Voting Rule)          %
%                                                                         %
%     Median_Voting_Rule_General.m :                                      %
%                                                                         %
%   [max_vote_mvr,z_mvr,MVR_Choice]=Median_Voting_Rule(fval)              %
%                                                                         %
%   Input:                                                                %
%      fval:                                                              %
%             A matrix which contains the objective values of each        %
%           stratey. The number of strategies is equal to fval's          %
%           rows and the number of objectives is equal to fval's          %
%           columns.                                                      %
%                                                                         %
%   Output:                                                               %
%      max_vote_mvr:                                                      %
%             Number of times when the best strategy gained vote          %
%           from voters.                                                  %
%      fval_mvr:                                                          %
%             Values of the strategy which gained maximum vote.           %
%      MVR_Choice:                                                        %
%             Number of strategy which gained maximum vote.               %
%           strategies.                                                   %
%                                                                         %
%   Programmed By:                                                        %
%           Mohammad Sadegh (Maisam) Khorshidi Ali Kordi                  %
%            Completed & Tested on 24.11.94 (2.13.2016)                   %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
z_fval=cell(size(fval,2),1);
z_sort=cell(size(fval,2),1);
for i=1:size(fval,2)
    z_fval{i}=[zeros(size(fval,1),1) fval];
    z_sort{i}=[];
    for j=1:size(fval,1)
        z_fval{i}(j,1)=j;
    end
end
for j=1:size(fval,2)
    for i=1:size(fval,1)
        [r,~]=find(z_fval{j}(:,j+1)==min(z_fval{j}(:,j+1)));
        z_sort{j}=[z_sort{j};z_fval{j}(r(1),:)];
        z_fval{j}(r(1),:)=[];
    end
end
z_num=zeros(size(fval));
for i=1:size(fval,2)
    z_num(:,i)=z_sort{i}(:,1);
end
for i=1:size(fval,1)
    clear histogram
    histogram=hist(reshape(z_num(1:i,:),[1 size(fval,2)*i]),1:size(fval,1));
    max_vote_mvr=max(histogram);
    if max_vote_mvr<floor(size(fval,2)./2)+1
        continue
    else
        MVR_Choice=find(histogram==max_vote_mvr);
        break
    end
end
fval_mvr=fval(MVR_Choice,:);