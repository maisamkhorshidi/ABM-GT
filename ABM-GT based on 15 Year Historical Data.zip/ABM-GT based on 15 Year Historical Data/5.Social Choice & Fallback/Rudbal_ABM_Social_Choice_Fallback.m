clc
clear
load Rudbal_Crisp_Game_ABM.mat
% Cell structure will contain 3 rows which corresponds to each Scenario
% and 5 columns which corresponds to each year, each cell will contain
% a matrix with 4 rows which corresponds to each game as follows:
% 1. CLC
% 2. CWLC
% 3. CPLC
% 4. CSV
% and 4 columns which corresponds to each player from 1 to 4 
fval_games=cell(3,1);
Score=cell(3,1);
sum_Score=cell(3,1);
fval_Borda=cell(3,1);
Borda_Choice=cell(3,1);
win_Con=cell(3,1);
los_Con=cell(3,1);
prefer_Con=cell(3,1);
fval_Con=cell(3,1);
Con_Choice=cell(3,1);
max_vote_mvr=cell(3,1);
fval_mvr=cell(3,1);
MVR_Choice=cell(3,1);
max_vote_plu=cell(3,1);
fval_plurality=cell(3,1);
Plurality_Choice=cell(3,1);
max_vote_qafb=cell(3,1);
fval_qafb=cell(3,1);
QAFB_Choice=cell(3,1);
max_vote_ufb=cell(3,1);
fval_ufb=cell(3,1);
UFB_Choice=cell(3,1);
for i=1:3
    for j=1:1
       fval_games{i,j}=zeros(4,4);
       fval_games{i,j}(1,:)=Total_payoff_CLC{i}(j,:);
       fval_games{i,j}(2,:)=Total_payoff_CWLC{i}(j,:);
       fval_games{i,j}(3,:)=Total_payoff_CPLC{i}(j,:);
       fval_games{i,j}(4,:)=Total_payoff_CSV{i}(j,:);
        % Borda Scoring
        [Score{i,j},sum_Score{i,j},fval_Borda{i,j},Borda_Choice{i,j}]=...
            Borda_Scoring_General(fval_games{i,j});
        % Condorcet Choice
        [win_Con{i,j},los_Con{i,j},prefer_Con{i,j},fval_Con{i,j},Con_Choice{i,j}]=...
            Condorcet_Choice_General(fval_games{i,j});
        % Median Voting Rule
        [max_vote_mvr{i,j},fval_mvr{i,j},MVR_Choice{i,j}]=Median_Voting_Rule_General(fval_games{i,j});
        % Plurality Choice Rule
        [max_vote_plu{i,j},fval_plurality{i,j},Plurality_Choice{i,j}]=...
            Plurality_Choice_Rule_General(fval_games{i,j});
        % q Approval Fallback Bargaining
        q=3;
        [max_vote_qafb{i,j},fval_qafb{i,j},QAFB_Choice{i,j}]=...
            q_Approval_Fallback_Bargaining_General(fval_games{i,j},q);
        % Unanimity Fallback Bargaining
        [max_vote_ufb{i,j},fval_ufb{i,j},UFB_Choice{i,j}]=...
            Unanimity_Fallback_Bargaining_General(fval_games{i,j});
    end
end
save('Rudbal_ABM_Social_Choice_Fallback.mat','q','fval_games','Score','sum_Score',...
    'fval_Borda','Borda_Choice','win_Con','los_Con','prefer_Con','fval_Con',...
    'Con_Choice','max_vote_mvr','fval_mvr','MVR_Choice','max_vote_plu','fval_plurality',...
    'Plurality_Choice','max_vote_qafb','fval_qafb','QAFB_Choice','max_vote_ufb',...
    'fval_ufb','UFB_Choice');