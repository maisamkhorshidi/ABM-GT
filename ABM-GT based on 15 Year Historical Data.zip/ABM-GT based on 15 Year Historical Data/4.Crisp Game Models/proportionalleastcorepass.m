function y=proportionalleastcorepass(x)
global A b beq num_players
% correcting values
payoff=zeros(1,num_players);
for i=1:num_players
    payoff(i)=x(i)./sum(x).*beq;
end
eps_coal=zeros(num_players,1);
benef_cal=zeros(2^num_players-2,1);
for i=1:2^num_players-2
    benef_cal(i)=sum(A(i,:).*payoff);
    eps_coal(i)=1-benef_cal(i)./b(i);
end
y=max(eps_coal);