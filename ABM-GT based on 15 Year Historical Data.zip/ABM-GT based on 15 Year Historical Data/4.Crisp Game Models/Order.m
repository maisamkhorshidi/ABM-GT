function order_matrix=Order(num_things)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%               MATLAB Code For Order of Choosing n Things                %
%                                                                         %
%     Order.m :                                                           %
%                                                                         %
%   order_matrix=Order(num_things)                                        %
%                                                                         %
%   Input:                                                                %
%      num_things:                                                        %
%             Number of things to be orderly selected.                    %
%                                                                         %
%   Output:                                                               %
%      order_matrix:                                                      %
%             A matrix which its rows contain the order of selec-         %
%           tion and number of rows is equal to n!.                       %
%                                                                         %
%                                                                         %
%   Programmed By:                                                        %
%           Mohammad Sadegh (Maisam) Khorshidi Ali Kordi                  %
%            Completed & Tested on 28.6.95 (9.18.2016)                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
order_matrix=zeros(factorial(num_things),num_things);
for i=1:factorial(num_things)
    player_available=cell(1,num_things);
    for j=1:num_things
            if j==1
                player_available{j}=zeros(1,num_things);
                for k=1:num_things
                    player_available{j}(k)=k;
                end
            else
                player_available{j}=zeros(1,num_things-(j-1));
                w=1;
                for k=1:size(player_available{j-1},2)
                    if order_matrix(i,j-1)==player_available{j-1}(k)
                    else
                        player_available{j}(w)=player_available{j-1}(k);
                        w=w+1;
                    end
                end
            end
            order_matrix(i,j)=player_available{j}(ceil(ceil(...
                    rem(i-1,factorial(num_things-(j-1)))+1e-3)./factorial(num_things-1-(j-1))));
    end
end