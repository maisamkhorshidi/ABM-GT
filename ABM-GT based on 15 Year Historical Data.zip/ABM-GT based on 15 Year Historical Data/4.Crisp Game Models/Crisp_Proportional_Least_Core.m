function [Total_payoff,epsilon]=Crisp_Proportional_Least_Core(...
    coalition_benefit,error_check,display)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%               MATLAB Code For Crisp Proportional Least Core             %
%                                                                         %
%     Crisp_Proportional_Least_Core.m :                                   %
%                                                                         %
%   [Total_payoff,epsilon]=Crisp_Proportional_Least_Core(...              %
%    coalition_benefit,display)                                           %
%                                                                         %
%   Input:                                                                %
%      coalition_benefit:                                                 %
%             A cell which its first column contains vectors of           %
%           coalition combination of playes, note that the ind-           %
%           ividual coalitions must be a vector with one component        %
%           equal to 1 and others equal to 0, the second colum-           %
%           n must contain the benefit value of corresponding             %
%           coalition. An example of this cell will be shown in           %
%           the example below.                                            %
%                                                                         %
%      error_check:                                                       %
%             Variable of type string just as 'true' or 'false'.          %
%           this option allows the program to check for possible          %
%           errors in Input Data.                                         %
%                                                                         %
%      display:                                                           %
%             Variable of type string just as 'on' or 'off'. th-          %
%           is option allows the program to print the messages            %
%           for the user.                                                 %
%                                                                         %
%   Output:                                                               %
%      Total_payoff:                                                      %
%             A matrix which contains the payoffs to each player.         %
%           the first element is the payoff to first player and           %
%           so on.                                                        %
%                                                                         %
%      epsilon:                                                           %
%             An scalar which is value of epsilon obtained from op-       %
%           timization process.                                           %
%                                                                         %
%                                                                         %
%       EXAMPLE:                                                          %
%                                                                         %
%            Table of cost, benefit coeficients and Coalition co-         %
%          binations are given below. Determine the epsilon and           %
%          payoff to each player.                                         %
%            The data input of this example saved with the follo-         %
%          wing name in the main folder:                                  %
%               "test_coalition_benefit_test.mat"                         %
%                                                                         %
%              Num. Coalition	Coalition	Cost$M	Benefit$M             %
%                   1	           A	      6.5	   0                  %
%                   2	           B	      4.2	   0                  %
%                   3	           C	      1.5      0                  %
%                   4	         {B,C}        5.3     0.4                 %
%                   5            {A,B}        10.3    0.4                 %
%                   6            {A,C}         8       0                  %
%                   7           {A,B,C}       10.6    1.6                 %
%                                                                         %
%       SOLUTION:                                                         %
%          Input:                                                         %
%                                                                         %
%        coalition_participation_benefit =                                %
%                                                                         %
%          [1,0,0]                     0                                  %
%          [0,1,0]                     0                                  %
%          [0,0,1]                     0                                  %
%          [1,1,1]                    0.4                                 %
%          [1,1,0]                    0.4                                 %
%          [1,0,1]                     0                                  %
%          [0,1,1]                    1.6                                 %
%             ^                        ^                                  %
%             |                        |                                  %
%         Coalition               Benefit Values                          %
%        Combination                                                      %
%                                                                         %
%                                                                         %
%          Output:                                                        %
%                                                                         %
%     Total_payoff =                                                      %
%                      player 1  player 2  player 3                       %
%                         0         2         0                           %
%                                                                         %
%     epsilon =                                                           %
%                      -3                                                 %
%                                                                         %
%   Programmed By:                                                        %
%           Mohammad Sadegh (Maisam) Khorshidi Ali Kordi                  %
%            Completed & Tested on 23.6.95 (9.14.2016)                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global A b beq num_players
num_players=size(coalition_benefit{1,1},2);
num_coalition=2.^num_players-num_players-1;
%% Checking for Errors
if strcmp(error_check,'true')
    if strcmp(display,'on')
        disp('Checking for errors')
    end
    if size(coalition_benefit,1)~=num_coalition+num_players
        error('\n%s','Error Occured:',...
            '        Number of rows of input cell must be equal to',...
            '        2^(number of players)-1.')
    end
    if size(coalition_benefit,2)~=2
        error('\n%s','Error Occured:','Number of columns of input cell must be equal to 2:',...
            '        First column must contain Coalition Combination Vectors.',...
            '        Second column must contain Benefit Functions.')
    end
    err_1=0;
    err_2=0;
    for i=1:size(coalition_benefit,1)
        if sum(coalition_benefit{i,1}==0+...
                coalition_benefit{i,1}==1)~=num_players
            err_1=err_1+1;
        end
        if size(coalition_benefit{i,1},2)~=num_players ||...
                size(coalition_benefit{i,1},1)~=1
            err_2=err_2+1;
        end
    end
    if err_1~=0
        error('\n%s','Error Occured:',...
            '        Coalition Combination Vector must contain 1"s and 0"s only.')
    end
    if err_2~=0
        error('\n%s','Error Occured:',...
            '        Dimension of one or more Coalition Combination Vectors',...
            '        are inconsistent.')
    end
    err_4=0;
    for i=1:num_coalition+num_players
        for j=num_coalition+num_players
            if i==j
                continue
            end
            if sum(coalition_benefit{i,1}==...
                    coalition_benefit{j,1})==num_players
                err_4=err_4+1;
            end
        end
    end
    if err_4~=0
        error('\n%s','Error Occured:',...
            '        Two or more Coalition Combination Vectors are identical.')
    end
    test_comb=zeros(2.^num_players-1,num_players);
    for j=2:2^num_players
        for i=1:num_players
            test_comb(j-1,i)=floor(rem(j/2^(num_players-i)-1e-5,2));
        end
    end
    for i=1:num_coalition+num_players
        err_5=0;
        for j=1:num_coalition+num_players
            if sum(coalition_benefit{i,1}==...
                    test_comb(j,:))==num_players
                err_5=err_5+1;
            end
        end
        if err_5~=1
            error('\n%s','Error Occured:',...
                '        The First column of input cell must contain all',...
                '        possible combination of coalitions.')
        end
    end
    err_6=0;
    for i=1:num_coalition+num_players
        if sum(coalition_benefit{i,1}>=...
                coalition_benefit{i,2})~=num_players
            err_6=err_6+1;
        end
    end
    if err_6~=0
        error('\n%s','Error Occured:',...
            '        One or more Coalition Combination Vectors are inconsistent',...
            '        with corresponding Participation Ratio Vectors.')
    end
    if strcmp(display,'on')
        disp('No error found.')
    end
end
%% Calculating each coalition's benefit
if strcmp(display,'on')
    disp('Constructing Constraints...')
end
A=zeros(2^num_players-2,num_players);
b=zeros(2^num_players-2,1);
j=1;
for i=1:2^num_players-1
    if sum(coalition_benefit{i,1}==ones(1,num_players))==num_players
        continue
    end
    A(j,:)=coalition_benefit{i,1};
    b(j)=coalition_benefit{i,2};
    j=j+1;
end
for i=1:size(coalition_benefit,1)
    if sum(coalition_benefit{i,1}==ones(1,num_players))==num_players
        beq=coalition_benefit{i,2};
    end
end
%% Optimization
if strcmp(display,'on')
    disp('Begining Optimization Process...')
    options = gaoptimset('PopulationSize',10.*num_players,...
        'Display','iter','Generations',100.*num_players);
else
    options = gaoptimset('PopulationSize',10.*num_players,'Generations',100.*num_players);
end
lb=zeros(1,num_players);
ub=ones(1,num_players);
[x,fval,exitflag]=ga(@proportionalleastcorepass,num_players,[],[],[],[],lb,ub,[],options);      
if isempty(x) || isempty(fval) || exitflag<=-2
    epsilon=0;
    Total_payoff=-ones(1,num_players).*inf;
else
    epsilon=fval;
    Total_payoff=x./sum(x).*beq;
end