clc
clear
tic
global S_normal S_max S_min S1 h I Rain E D_1
global D_2 D_3 D_4 D_e D_i D_dr Ratio_return 
global allowable_dr Coal_00_Ratio_pure_allReturn_demand_1
global eff_0_1 eff_1_2 eff_2_3 eff_3_4
global Scenario t compare_value stall population gen fval_w_pen_each_gen 
global fval_each_gen vio_s_each_gen vio_dr_gr_each_gen vio_f_each_gen 
global vio_r_each_gen vio_nb_each_gen Ratio_Mass_Area Ratio_Price_Mass
global Area_p1 Area_p2 Area_p3 Area_p4 fragment
global comunication coop_1st_year net
%% Lodaing & Reading Data
load('Coal_00_MATLAB_ABM.mat','S_normal','S_max','S_min','S1','Ratio_return',...
    'eff_0_1','eff_1_2','eff_2_3','eff_3_4','net',...
    'Coal_00_Ratio_pure_allReturn_demand_1','Coal_00_GA_Variables');
load Data_for_Game.mat
load comunication.mat
load coop_1st_year.mat
if exist('Coal_04_MATLAB_ABM.mat','file')~=0
    load Coal_04_MATLAB_ABM.mat
else
    Coal_04_Initial_Guess=cell(3,1);
    Coal_04_GA_Variables=cell(3,1);
    Coal_04_fvalue=cell(3,1);
    Coal_04_final_population=cell(3,1);
    Coal_04_Pure_allReturn_1=cell(3,1);
    Coal_04_Pure_allReturn_2=cell(3,1);
    Coal_04_Pure_allReturn_3=cell(3,1);
    Coal_04_Pure_allReturn_4=cell(3,1);
    Coal_04_Ratio_pure_all_dam_all_total_1=cell(3,1);
    Coal_04_Ratio_pure_all_dam_all_total_2=cell(3,1);
    Coal_04_Ratio_pure_all_dam_all_total_3=cell(3,1);
    Coal_04_Ratio_pure_all_dam_all_total_4=cell(3,1);
    Coal_04_R=cell(3,1);
    Coal_04_SP=cell(3,1);
    Coal_04_S=cell(3,1);
    Coal_04_Vol_Rain=cell(3,1);
    Coal_04_Vol_E=cell(3,1);
    Coal_04_vio_S=cell(3,1);
    Coal_04_all_gr_1=cell(3,1);
    Coal_04_all_gr_2=cell(3,1);
    Coal_04_all_gr_3=cell(3,1);
    Coal_04_all_gr_4=cell(3,1);
    Coal_04_Allocation_gr=cell(3,1);
    Coal_04_vio_dr_gr=cell(3,1);
    Coal_04_vio_f=cell(3,1);
    Coal_04_vio_R=cell(3,1);
    Coal_04_flow_river_down_0=cell(3,1);
    Coal_04_flow_river_up_1=cell(3,1);
    Coal_04_flow_river_in_1=cell(3,1);
    Coal_04_flow_river_down_1=cell(3,1);
    Coal_04_flow_river_up_2=cell(3,1);
    Coal_04_flow_river_in_2=cell(3,1);
    Coal_04_flow_river_down_2=cell(3,1);
    Coal_04_flow_river_up_3=cell(3,1);
    Coal_04_flow_river_in_3=cell(3,1);
    Coal_04_flow_river_down_3=cell(3,1);
    Coal_04_flow_river_up_4=cell(3,1);
    Coal_04_Environmental_Flow=cell(3,1);
    Coal_04_all_dam_1=cell(3,1);
    Coal_04_all_dam_2=cell(3,1);
    Coal_04_all_dam_3=cell(3,1);
    Coal_04_all_dam_4=cell(3,1);
    Coal_04_all_return_1=cell(3,1);
    Coal_04_all_return_2=cell(3,1);
    Coal_04_all_return_3=cell(3,1);
    Coal_04_all_return_4=cell(3,1);
    non_Coop_Ratio_pure_allReturn_demand=cell(3,1);
    Coal_04_Ratio_pure_allReturn_demand_1=cell(3,1);
    Coal_04_Ratio_pure_allReturn_demand_2=cell(3,1);
    Coal_04_Ratio_pure_allReturn_demand_3=cell(3,1);
    Coal_04_Ratio_pure_allReturn_demand_4=cell(3,1);
    Coal_04_Total_benefit=cell(3,1);
    Coal_04_vio_net_benefit=cell(3,1);
    Coal_04_benefit_p1=cell(3,1);
    Coal_04_benefit_p2=cell(3,1);
    Coal_04_benefit_p3=cell(3,1);
    Coal_04_benefit_p4=cell(3,1);
    Coal_04_vio_Ratio_all_demand=cell(3,1);
    Inflow=cell(3,1);
    Precipitation=cell(3,1);
    Evaporation=cell(3,1);
    Demand_1=cell(3,1);
    Demand_2=cell(3,1);
    Demand_3=cell(3,1);
    Demand_4=cell(3,1);
    Demand_e=cell(3,1);
    Demand_i=cell(3,1);
    Demand_dr=cell(3,1);
    max_dr_groundwater=cell(3,1);
    Demand_1_total=cell(3,1);
    Demand_2_total=cell(3,1);
    Demand_3_total=cell(3,1);
    Demand_4_total=cell(3,1);
    Coal_04_Ratio_benefit_Coal_non_Coop=cell(3,1);
    Coal_04_num_comunication_per_year=cell(3,1);
    Coal_04_coop_nth_year=cell(3,1);
    Coal_04_coop_non_coop=cell(3,1);
    Coal_04_Ratio_pure_allReturn_demand_ABM_1=cell(3,1);
    Coal_04_Ratio_pure_allReturn_demand_ABM_2=cell(3,1);
    Coal_04_Ratio_pure_allReturn_demand_ABM_3=cell(3,1);
    Coal_04_Ratio_pure_allReturn_demand_ABM_4=cell(3,1);
    Coal_04_net_benefit=cell(3,1);
    Coal_04_Total_net_benefit=cell(3,1);
    Coal_04_dr_month_gr=cell(3,1);
    Coal_04_dr_year_gr=cell(3,1);
end
%% Input Parameters
% Scenarios:
% [3,1] Very Dry
% [5,1] Normal
% [5,5] Ver Very Wet
% Ratio of Return Flow
h=60;
Scenario_start=1;
Scenario_end=3;
num_var=5*h/12;
population=15*num_var;
Generations=300;
fragment=1;
% IntCon=zeros(1,num_var);
% for i=1:num_var
%     IntCon(i)=i;
% end
IntCon=[];
%% Computation of Each Scenario
for Scenario=Scenario_start:Scenario_end
    %% Some Dummy Parameters For Displaying Iterations
    compare_value=zeros(2,1);
    stall=0;
    gen=0;
    t=0;
    fval_w_pen_each_gen=zeros(population,1);
    fval_each_gen=zeros(population,1);
    vio_s_each_gen=zeros(population,1);
    vio_r_each_gen=zeros(population,1);
    vio_dr_gr_each_gen=zeros(population,1);
    vio_f_each_gen=zeros(population,1);
    vio_nb_each_gen=zeros(population,1);
    vio_all_each_gen=zeros(population,1);
    %% Read Data From Text File
    [I,Rain,E,D_1_total,D_2_total,D_3_total,D_4_total,D_1,D_2,D_3,D_4,D_e,...
    D_i,D_dr,allowable_dr,lb,ub]=Read_Data_Text(Scenario,num_var,h);
    ub=ub./fragment;
    Inflow{Scenario}=I;
    Precipitation{Scenario}=Rain;
    Evaporation{Scenario}=E;
    Demand_1{Scenario}=D_1;
    Demand_2{Scenario}=D_2;
    Demand_3{Scenario}=D_3;
    Demand_4{Scenario}=D_4;
    Demand_e{Scenario}=D_e;
    Demand_i{Scenario}=D_i;
    Demand_dr{Scenario}=D_dr;
    max_dr_groundwater{Scenario}=allowable_dr;
    Demand_1_total{Scenario}=D_1_total;
    Demand_2_total{Scenario}=D_2_total;
    Demand_3_total{Scenario}=D_3_total;
    Demand_4_total{Scenario}=D_4_total;
    Coal_04_Initial_Guess{Scenario}=[Coal_00_GA_Variables{Scenario}(1:h/12),...
        Coal_00_GA_Variables{Scenario}(1:h/12),Coal_00_GA_Variables{Scenario}(1:h/12),...
        Coal_00_GA_Variables{Scenario}(1:h/12),Coal_00_GA_Variables{Scenario}(h/12+1:end)];
    %% Calling GA For Optimization Process
    disp(['Coalition 04 - Scenario # ' num2str(Scenario) ' of 3'])
    %'InitialPop',Coal_04_final_population{Scenario},'Display','iter','StallGenLimit',100
    %'PlotFcns',@gaplotbestf,'Vectorized','on','UseParallel',true,
    % Coal_04_Initial_Guess{Scenario},
    options = gaoptimset('InitialPop',Coal_04_final_population{Scenario},...
        'PopulationSize',population,'Generations',Generations,'StallGenLimit',50);
    [variables,fval,exitflag,output,final_pop]=ga(@Coal_04_singlefcn_abm,num_var,[],[],[],[],...
        lb,ub,[],IntCon,options);
    Coal_04_GA_Variables{Scenario}=variables;
    Coal_04_fvalue{Scenario}=fval;
    Coal_04_final_population{Scenario}=final_pop;
    %% Computing Storage & Release & Spillway Release & Allocations
    [Coal_04_Pure_allReturn_1{Scenario},Coal_04_Pure_allReturn_2{Scenario},...
        Coal_04_Pure_allReturn_3{Scenario},Coal_04_Pure_allReturn_4{Scenario},...
        Coal_04_all_gr_1{Scenario},Coal_04_all_gr_2{Scenario},Coal_04_all_gr_3{Scenario},...
        Coal_04_all_gr_4{Scenario},Coal_04_Allocation_gr{Scenario},Coal_04_R{Scenario},...
        Coal_04_Ratio_pure_allReturn_demand_1{Scenario},Coal_04_Ratio_pure_allReturn_demand_2{Scenario},...
        Coal_04_Ratio_pure_allReturn_demand_3{Scenario},Coal_04_Ratio_pure_allReturn_demand_4{Scenario},...
        Coal_04_Ratio_pure_all_dam_all_total_1{Scenario},...
        Coal_04_Ratio_pure_all_dam_all_total_2{Scenario},Coal_04_Ratio_pure_all_dam_all_total_3{Scenario},...
        Coal_04_Ratio_pure_all_dam_all_total_4{Scenario},Coal_04_S{Scenario},...
        Coal_04_SP{Scenario},Coal_04_Vol_Rain{Scenario},Coal_04_Vol_E{Scenario},...
        Coal_04_vio_dr_gr{Scenario},Coal_04_vio_S{Scenario},Coal_04_vio_f{Scenario},...
        Coal_04_vio_R{Scenario},Coal_04_flow_river_down_0{Scenario},...
        Coal_04_flow_river_up_1{Scenario},Coal_04_flow_river_in_1{Scenario},...
        Coal_04_flow_river_down_1{Scenario},Coal_04_flow_river_up_2{Scenario},...
        Coal_04_flow_river_in_2{Scenario},Coal_04_flow_river_down_2{Scenario},...
        Coal_04_flow_river_up_3{Scenario},Coal_04_flow_river_in_3{Scenario},...
        Coal_04_flow_river_down_3{Scenario},Coal_04_flow_river_up_4{Scenario},...
        Coal_04_all_dam_1{Scenario},Coal_04_all_dam_2{Scenario},Coal_04_all_dam_3{Scenario},...
        Coal_04_all_dam_4{Scenario},Coal_04_all_return_1{Scenario},Coal_04_all_return_2{Scenario},...
        Coal_04_all_return_3{Scenario},Coal_04_all_return_4{Scenario},...
        Coal_04_Environmental_Flow{Scenario},non_Coop_Ratio_pure_allReturn_demand{Scenario},...
        Coal_04_Total_benefit{Scenario},Coal_04_vio_net_benefit{Scenario},...
        Coal_04_benefit_p1{Scenario},Coal_04_benefit_p2{Scenario},Coal_04_benefit_p3{Scenario},...
        Coal_04_benefit_p4{Scenario},Coal_04_Ratio_benefit_Coal_non_Coop{Scenario},Coal_04_num_comunication_per_year{Scenario},...
        Coal_04_coop_nth_year{Scenario},Coal_04_coop_non_coop{Scenario},Coal_04_Ratio_pure_allReturn_demand_ABM_1{Scenario},...
        Coal_04_Ratio_pure_allReturn_demand_ABM_2{Scenario},Coal_04_Ratio_pure_allReturn_demand_ABM_3{Scenario},...
        Coal_04_Ratio_pure_allReturn_demand_ABM_4{Scenario},Coal_04_net_benefit{Scenario},Coal_04_Total_net_benefit{Scenario},...
        Coal_04_dr_month_gr{Scenario},Coal_04_dr_year_gr{Scenario}]=...
        Coal_04_Allocation_Calculation_ABM(variables,Inflow,Evaporation,Precipitation,...
        Demand_1,Demand_2,Demand_3,Demand_4,Demand_e,Demand_i,Demand_dr,...
        S1,S_min,S_max,S_normal,Ratio_return,eff_0_1,eff_1_2,eff_2_3,eff_3_4,...
        max_dr_groundwater,Coal_00_Ratio_pure_allReturn_demand_1,...
        Ratio_Mass_Area,Ratio_Price_Mass,Area_p1,Area_p2,Area_p3,Area_p4,comunication,coop_1st_year,...
        fragment,net,Scenario,h);
    %% Saving Result
    save('Coal_04_MATLAB_ABM.mat','Coal_04_fvalue','Coal_04_GA_Variables',...
        'Coal_04_final_population','Coal_04_Pure_allReturn_1','Coal_04_Pure_allReturn_2',...
        'Coal_04_Pure_allReturn_3','Coal_04_Pure_allReturn_4','Coal_04_R','Coal_04_S',...
        'Coal_04_SP','Coal_04_Vol_Rain','Coal_04_Vol_E','Coal_04_vio_dr_gr','Coal_04_vio_S',...
        'Coal_04_Ratio_pure_allReturn_demand_1','Coal_04_Ratio_pure_allReturn_demand_2',...
        'Coal_04_Ratio_pure_allReturn_demand_3','Coal_04_Ratio_pure_allReturn_demand_4',...
        'Coal_04_Ratio_pure_all_dam_all_total_1','Coal_04_Ratio_pure_all_dam_all_total_2',...
        'Coal_04_Ratio_pure_all_dam_all_total_3','Coal_04_Ratio_pure_all_dam_all_total_4',...
        'Coal_04_all_gr_1','Coal_04_all_gr_2','Coal_04_all_gr_3','Coal_04_all_gr_4',...
        'Coal_04_Allocation_gr','Coal_04_vio_f','Coal_04_vio_R','Coal_04_flow_river_down_0',...
        'Coal_04_flow_river_up_1','Coal_04_flow_river_in_1','Coal_04_flow_river_down_1',...
        'Coal_04_flow_river_up_2','Coal_04_flow_river_in_2','Coal_04_flow_river_down_2',...
        'Coal_04_flow_river_up_3','Coal_04_flow_river_in_3','Coal_04_flow_river_down_3',...
        'Coal_04_flow_river_up_4','Coal_04_all_dam_1','Coal_04_all_dam_2','Coal_04_all_dam_3',...
        'Coal_04_all_dam_4','Coal_04_all_return_1','Coal_04_all_return_2','Coal_04_all_return_3',...
        'Coal_04_all_return_4','Coal_04_Environmental_Flow','Inflow','Precipitation',...
        'Evaporation','Demand_1','Demand_2','Demand_3','Demand_4','Demand_e',...
        'Demand_i','Demand_dr','max_dr_groundwater','S_normal','S_max','S_min',...
        'S1','Ratio_return','eff_0_1','eff_1_2','eff_2_3','eff_3_4',...
        'non_Coop_Ratio_pure_allReturn_demand',...
        'Ratio_Mass_Area','Ratio_Price_Mass','Area_p1','Area_p2','Area_p3','Area_p4',...
        'Coal_04_Total_benefit','Coal_04_vio_net_benefit',...
        'Coal_04_benefit_p1','Coal_04_benefit_p2','Coal_04_benefit_p3',...
        'Coal_04_benefit_p4','fragment',...
        'Demand_1_total','Demand_2_total','Demand_3_total','Demand_4_total',...
        'Coal_04_Ratio_benefit_Coal_non_Coop','Coal_04_num_comunication_per_year',...
        'Coal_04_coop_nth_year','Coal_04_coop_non_coop','Coal_04_Ratio_pure_allReturn_demand_ABM_1',...
        'Coal_04_Ratio_pure_allReturn_demand_ABM_2','Coal_04_Ratio_pure_allReturn_demand_ABM_3',...
        'Coal_04_Ratio_pure_allReturn_demand_ABM_4','Coal_04_net_benefit','Coal_04_net_benefit','net',...
        'Coal_04_dr_month_gr','Coal_04_dr_year_gr');
end
toc