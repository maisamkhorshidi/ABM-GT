clc
clear
rand_comunication=randi([1,79],80,15+15*6*4);
for i=1:80
    for j=1:15+15*6*4
        if rand_comunication(i,j)>=i
            rand_comunication(i,j)=rand_comunication(i,j)+1;
        end
    end
end
comunication=rand_comunication;
save('comunication.mat','comunication');