% Matrix of Cooperation and level of cooperation in first year
clc
clear
probability_coop=0.5;
level_coop=4;
agents=80;
coop_1st_year=zeros(agents,1);
agent_num=zeros(agents*probability_coop,1);
for i=1:probability_coop*agents
    agent_num(i)=randi([1,agents],1,1);
    while sum(agent_num==agent_num(i))>1
        agent_num(i)=randi([1,agents],1,1);
    end
    coop_1st_year(agent_num(i))=randi([1,level_coop],1,1)/level_coop;
end
save('coop_1st_year.mat','coop_1st_year')