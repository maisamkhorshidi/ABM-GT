function [Coal_02_Pure_allReturn_1,Coal_02_Pure_allReturn_2,...
    Coal_02_Pure_allReturn_3,Coal_02_Pure_allReturn_4,...
    Coal_02_all_gr_1,Coal_02_all_gr_2,Coal_02_all_gr_3,...
    Coal_02_all_gr_4,Coal_02_Allocation_gr,Coal_02_R,...
    Coal_02_Ratio_pure_allReturn_demand_1,Coal_02_Ratio_pure_allReturn_demand_2,...
    Coal_02_Ratio_pure_allReturn_demand_3,Coal_02_Ratio_pure_allReturn_demand_4,...
    Coal_02_Ratio_pure_all_dam_all_total_1,...
    Coal_02_Ratio_pure_all_dam_all_total_2,Coal_02_Ratio_pure_all_dam_all_total_3,...
    Coal_02_Ratio_pure_all_dam_all_total_4,Coal_02_S,...
    Coal_02_SP,Coal_02_Vol_Rain,Coal_02_Vol_E,...
    Coal_02_vio_dr_gr,Coal_02_vio_S,Coal_02_vio_f,...
    Coal_02_vio_R,Coal_02_flow_river_down_0,...
    Coal_02_flow_river_up_1,Coal_02_flow_river_in_1,...
    Coal_02_flow_river_down_1,Coal_02_flow_river_up_2,...
    Coal_02_flow_river_in_2,Coal_02_flow_river_down_2,...
    Coal_02_flow_river_up_3,Coal_02_flow_river_in_3,...
    Coal_02_flow_river_down_3,Coal_02_flow_river_up_4,...
    Coal_02_all_dam_1,Coal_02_all_dam_2,Coal_02_all_dam_3,...
    Coal_02_all_dam_4,Coal_02_all_return_1,Coal_02_all_return_2,...
    Coal_02_all_return_3,Coal_02_all_return_4,...
    Coal_02_Environmental_Flow,non_Coop_Ratio_pure_allReturn_demand,...
    Coal_02_Total_benefit,Coal_02_vio_net_benefit,...
    Coal_02_benefit_p1,Coal_02_benefit_p2,Coal_02_benefit_p3,...
    Coal_02_benefit_p4,Coal_02_Ratio_benefit_Coal_non_Coop,Coal_02_num_comunication_per_year,...
    Coal_02_coop_nth_year,Coal_02_coop_non_coop,Coal_02_Ratio_pure_allReturn_demand_ABM_1,...
    Coal_02_Ratio_pure_allReturn_demand_ABM_2,Coal_02_Ratio_pure_allReturn_demand_ABM_3,...
    Coal_02_Ratio_pure_allReturn_demand_ABM_4,Coal_02_net_benefit,Coal_02_Total_net_benefit,...
    Coal_02_dr_month_gr,Coal_02_dr_year_gr]=...
        Coal_02_Allocation_Calculation_ABM(variables,Inflow,Evaporation,Precipitation,...
        Demand_1,Demand_2,Demand_3,Demand_4,Demand_e,Demand_i,Demand_dr,...
        S1,S_min,S_max,S_normal,Ratio_return,eff_0_1,eff_1_2,eff_2_3,eff_3_4,...
        max_dr_groundwater,Coal_00_Ratio_pure_allReturn_demand_1,...
        Ratio_Mass_Area,Ratio_Price_Mass,Area_p1,Area_p2,Area_p3,Area_p4,comunication,coop_1st_year,...
        fragment,net,Scenario,h)
% Assigning Scenario Values
D_1=Demand_1{Scenario};
D_2=Demand_2{Scenario};
D_3=Demand_3{Scenario};
D_4=Demand_4{Scenario};
D_e=Demand_e{Scenario};
D_i=Demand_i{Scenario};
D_dr=Demand_dr{Scenario};
I=Inflow{Scenario};
Rain=Precipitation{Scenario};
E=Evaporation{Scenario};
non_Coop_Ratio_pure_allReturn_demand=Coal_00_Ratio_pure_allReturn_demand_1{Scenario};
allowable_dr=max_dr_groundwater{Scenario};
% Normalizing Variables
variables=variables.*fragment;
% Calculating Demand Volume of Coalition & Users Allocation
sum_yearly_D_1=zeros(h/(h/12),1);
sum_yearly_D_3=zeros(h/(h/12),1);
for i=1:20
    sum_yearly_D_1=sum_yearly_D_1+D_1{i}(1:h/(h/12));
    sum_yearly_D_3=sum_yearly_D_3+D_3{i}(1:h/(h/12));
end
Coal_02_vol_demand=sum(sum_yearly_D_1+sum_yearly_D_3);
Coal_02_vol_all=non_Coop_Ratio_pure_allReturn_demand.*Coal_02_vol_demand;
%% Part 2 : Assigning Agricultural Management's Variables
% Ratio of pure allocation plus pure drainage of upstream users per demand, each
% variables corresponding to each year and all users.
Coal_02_Ratio_pure_allReturn_demand_1=zeros(1,h/12);
Coal_02_Ratio_pure_allReturn_demand_2=zeros(1,h/12);
Coal_02_Ratio_pure_allReturn_demand_3=zeros(1,h/12);
Coal_02_Ratio_pure_allReturn_demand_4=zeros(1,h/12);
for i=1:h/12
    if non_Coop_Ratio_pure_allReturn_demand(i)>=0.99
        Coal_02_Ratio_pure_allReturn_demand_1(i)=round(1);
        Coal_02_Ratio_pure_allReturn_demand_2(i)=round(1);
        Coal_02_Ratio_pure_allReturn_demand_3(i)=round(1);
        Coal_02_Ratio_pure_allReturn_demand_4(i)=round(1);
    else
        Coal_02_Ratio_pure_allReturn_demand_1(i)=Coal_02_vol_all(i).*variables(i)./sum(sum_yearly_D_1);
        Coal_02_Ratio_pure_allReturn_demand_2(i)=non_Coop_Ratio_pure_allReturn_demand(i);
        Coal_02_Ratio_pure_allReturn_demand_3(i)=Coal_02_vol_all(i).*(1-variables(i))./sum(sum_yearly_D_3);
        Coal_02_Ratio_pure_allReturn_demand_4(i)=non_Coop_Ratio_pure_allReturn_demand(i);
    end
end
for i=1:h/12
    if Coal_02_Ratio_pure_allReturn_demand_1(i)>=0.999
        Coal_02_Ratio_pure_allReturn_demand_1(i)=round(1);
    end
    if Coal_02_Ratio_pure_allReturn_demand_2(i)>=0.999
        Coal_02_Ratio_pure_allReturn_demand_2(i)=round(1);
    end
    if Coal_02_Ratio_pure_allReturn_demand_3(i)>=0.999
        Coal_02_Ratio_pure_allReturn_demand_3(i)=round(1);
    end
    if Coal_02_Ratio_pure_allReturn_demand_4(i)>=0.999
        Coal_02_Ratio_pure_allReturn_demand_4(i)=round(1);
    end
    if non_Coop_Ratio_pure_allReturn_demand(i)>=0.99
        non_Coop_Ratio_pure_allReturn_demand(i)=round(1);
    end
    if Coal_02_Ratio_pure_allReturn_demand_1(i)<=0.01
        Coal_02_Ratio_pure_allReturn_demand_1(i)=round(0);
    end
    if Coal_02_Ratio_pure_allReturn_demand_2(i)<=0.01
        Coal_02_Ratio_pure_allReturn_demand_2(i)=round(0);
    end
    if Coal_02_Ratio_pure_allReturn_demand_3(i)<=0.01
        Coal_02_Ratio_pure_allReturn_demand_3(i)=round(0);
    end
    if Coal_02_Ratio_pure_allReturn_demand_4(i)<=0.01
        Coal_02_Ratio_pure_allReturn_demand_4(i)=round(0);
    end
end
%% Part 3 : Agent Based Modeling - Determination of Cooperative and non-cooperative users
num_agents_1=20;
num_agents_2=20;
num_agents_3=20;
num_agents_4=20;
num_agents=num_agents_1+num_agents_2+num_agents_3+num_agents_4;
% Testing benefits for determination of memory effects of agents
Coal_02_benefit_p1=zeros(num_agents_1,h/12);
Coal_02_benefit_p2=zeros(num_agents_2,h/12);
Coal_02_benefit_p3=zeros(num_agents_3,h/12);
Coal_02_benefit_p4=zeros(num_agents_4,h/12);
Coal_02_Total_benefit=zeros(1,h/12);
non_Coop_benefit_p1=zeros(num_agents_1,h/12);
non_Coop_benefit_p2=zeros(num_agents_2,h/12);
non_Coop_benefit_p3=zeros(num_agents_3,h/12);
non_Coop_benefit_p4=zeros(num_agents_4,h/12);
Total_non_Coop_benefit=zeros(1,h/12);
Coal_02_Ratio_benefit_Coal_non_Coop=zeros(1,h/12);
% Determination of effects of comunications of agents
num_comunication_1st_year=15;
Coal_02_num_comunication_per_year=zeros(1,h/12);
Coal_02_coop_nth_year=zeros(num_agents,h/12);
Coal_02_coop_non_coop=zeros(num_agents,h/12);
Coal_02_Ratio_pure_allReturn_demand_ABM_1=zeros(num_agents_1,h/12);
Coal_02_Ratio_pure_allReturn_demand_ABM_2=zeros(num_agents_2,h/12);
Coal_02_Ratio_pure_allReturn_demand_ABM_3=zeros(num_agents_3,h/12);
Coal_02_Ratio_pure_allReturn_demand_ABM_4=zeros(num_agents_4,h/12);
Coal_02_net_benefit=zeros(num_agents,h/12);
Coal_02_Total_net_benefit=zeros(1,h/12);
for i=1:h/12
    if i==1
        Coal_02_coop_nth_year(:,i)=coop_1st_year;
        Coal_02_num_comunication_per_year(i)=num_comunication_1st_year;
    elseif Coal_02_Total_net_benefit(i-1)==0
        Coal_02_coop_nth_year(:,i)=coop_1st_year;
    else
        % Comunication effect
        % determining number of comunication per year on the basis of
        % benefit ratio
        if Coal_02_Ratio_benefit_Coal_non_Coop(i-1)<0.5 || Coal_02_Ratio_benefit_Coal_non_Coop(i-1)>1.5
            Coal_02_num_comunication_per_year(i)=floor(num_comunication_1st_year.*6);
        elseif Coal_02_Ratio_benefit_Coal_non_Coop(i-1)<=1.05 && Coal_02_Ratio_benefit_Coal_non_Coop(i-1)>0.95
            Coal_02_num_comunication_per_year(i)=floor(num_comunication_1st_year.*1);
        elseif Coal_02_Ratio_benefit_Coal_non_Coop(i-1)<=1.15 && Coal_02_Ratio_benefit_Coal_non_Coop(i-1)>1.05
            Coal_02_num_comunication_per_year(i)=floor(num_comunication_1st_year.*4);
        elseif Coal_02_Ratio_benefit_Coal_non_Coop(i-1)<=1.3 && Coal_02_Ratio_benefit_Coal_non_Coop(i-1)>1.15
            Coal_02_num_comunication_per_year(i)=floor(num_comunication_1st_year.*5);
        elseif Coal_02_Ratio_benefit_Coal_non_Coop(i-1)<=1.5 && Coal_02_Ratio_benefit_Coal_non_Coop(i-1)>1.3
            Coal_02_num_comunication_per_year(i)=floor(num_comunication_1st_year.*5.5);
        elseif Coal_02_Ratio_benefit_Coal_non_Coop(i-1)<=0.95 && Coal_02_Ratio_benefit_Coal_non_Coop(i-1)>0.85
            Coal_02_num_comunication_per_year(i)=floor(num_comunication_1st_year.*4);
        elseif Coal_02_Ratio_benefit_Coal_non_Coop(i-1)<=0.85 && Coal_02_Ratio_benefit_Coal_non_Coop(i-1)>0.7
            Coal_02_num_comunication_per_year(i)=floor(num_comunication_1st_year.*5);
        elseif Coal_02_Ratio_benefit_Coal_non_Coop(i-1)<=0.7 && Coal_02_Ratio_benefit_Coal_non_Coop(i-1)>0.5
            Coal_02_num_comunication_per_year(i)=floor(num_comunication_1st_year.*5.5);
        end
        for j=1:num_agents
            for k=1:Coal_02_num_comunication_per_year(i)
                if Coal_02_coop_nth_year(j,i-1)>Coal_02_coop_nth_year(comunication(j,sum(Coal_02_num_comunication_per_year(1:i-1))+k),i-1) &&...
                        Coal_02_Total_net_benefit(i-1)>0
                    Coal_02_coop_nth_year(j,i)=min(1,Coal_02_coop_nth_year(j,i)+0);
                    Coal_02_coop_nth_year(comunication(j,sum(Coal_02_num_comunication_per_year(1:i-1))+k),i)=...
                        min(1,Coal_02_coop_nth_year(comunication(j,sum(Coal_02_num_comunication_per_year(1:i-1))+k),i)+0.25);
                elseif Coal_02_coop_nth_year(j,i-1)<Coal_02_coop_nth_year(comunication(j,sum(Coal_02_num_comunication_per_year(1:i-1))+k),i-1) &&...
                        Coal_02_Total_net_benefit(i-1)>0
                    Coal_02_coop_nth_year(j,i)=min(1,Coal_02_coop_nth_year(j,i)+0.25);
                    Coal_02_coop_nth_year(comunication(j,sum(Coal_02_num_comunication_per_year(1:i-1))+k),i)=...
                        min(1,Coal_02_coop_nth_year(comunication(j,sum(Coal_02_num_comunication_per_year(1:i-1))+k),i)+0);
                elseif Coal_02_coop_nth_year(j,i-1)>Coal_02_coop_nth_year(comunication(j,sum(Coal_02_num_comunication_per_year(1:i-1))+k),i-1) &&...
                        Coal_02_Total_net_benefit(i-1)<0
                    Coal_02_coop_nth_year(j,i)=max(0,Coal_02_coop_nth_year(j,i)-0.25);
                    Coal_02_coop_nth_year(comunication(j,sum(Coal_02_num_comunication_per_year(1:i-1))+k),i)=...
                        max(0,Coal_02_coop_nth_year(comunication(j,sum(Coal_02_num_comunication_per_year(1:i-1))+k),i)-0);
                 elseif Coal_02_coop_nth_year(j,i-1)<Coal_02_coop_nth_year(comunication(j,sum(Coal_02_num_comunication_per_year(1:i-1))+k),i-1) &&...
                        Coal_02_Total_net_benefit(i-1)<0
                    Coal_02_coop_nth_year(j,i)=max(0,Coal_02_coop_nth_year(j,i)-0.25);
                    Coal_02_coop_nth_year(comunication(j,sum(Coal_02_num_comunication_per_year(1:i-1))+k),i)=...
                        max(0,Coal_02_coop_nth_year(comunication(j,sum(Coal_02_num_comunication_per_year(1:i-1))+k),i)-0);
                end
            end
        end
    end
    Coal_02_coop_non_coop(:,i)=Coal_02_coop_nth_year(:,i)>0;
    % Cooperation of Agents outside of coalition must be 0
    for j=1:num_agents
        if j>=num_agents_1+1 && j<=num_agents_1+num_agents_2
            Coal_02_coop_non_coop(j,i)=0;
        end
        if j>=num_agents_1+num_agents_2+num_agents_3+1 && j<=num_agents
            Coal_02_coop_non_coop(j,i)=0;
        end
    end
    % Calculation of allocation per demand for each agent
    for j=1:num_agents_1
        if Coal_02_coop_non_coop(j,i)==0
            Coal_02_Ratio_pure_allReturn_demand_ABM_1(j,i)=non_Coop_Ratio_pure_allReturn_demand(i);
        else
            Coal_02_Ratio_pure_allReturn_demand_ABM_1(j,i)=min(1,(1-Coal_02_coop_nth_year(j,i)).*...
                non_Coop_Ratio_pure_allReturn_demand(i)+Coal_02_Ratio_pure_allReturn_demand_1(i));
        end
    end
    for j=1:num_agents_2
        if Coal_02_coop_non_coop(num_agents_1+j,i)==0
            Coal_02_Ratio_pure_allReturn_demand_ABM_2(j,i)=non_Coop_Ratio_pure_allReturn_demand(i);
        else
            Coal_02_Ratio_pure_allReturn_demand_ABM_2(j,i)=min(1,(1-Coal_02_coop_nth_year(num_agents_1+j,i)).*...
                non_Coop_Ratio_pure_allReturn_demand(i)+Coal_02_Ratio_pure_allReturn_demand_2(i));
        end
    end
    for j=1:num_agents_3
        if Coal_02_coop_non_coop(num_agents_1+num_agents_2+j,i)==0
            Coal_02_Ratio_pure_allReturn_demand_ABM_3(j,i)=non_Coop_Ratio_pure_allReturn_demand(i);
        else
            Coal_02_Ratio_pure_allReturn_demand_ABM_3(j,i)=min(1,(1-Coal_02_coop_nth_year(num_agents_1+num_agents_2+j,i)).*...
                non_Coop_Ratio_pure_allReturn_demand(i)+Coal_02_Ratio_pure_allReturn_demand_3(i));
        end
    end
    for j=1:num_agents_4
        if Coal_02_coop_non_coop(num_agents_1+num_agents_2+num_agents_3+j,i)==0
            Coal_02_Ratio_pure_allReturn_demand_ABM_4(j,i)=non_Coop_Ratio_pure_allReturn_demand(i);
        else
            Coal_02_Ratio_pure_allReturn_demand_ABM_4(j,i)=min(1,(1-Coal_02_coop_nth_year(num_agents_1+num_agents_2+num_agents_3+j,i)).*...
                non_Coop_Ratio_pure_allReturn_demand(i)+Coal_02_Ratio_pure_allReturn_demand_4(i));
        end
    end
    % calculation of non cooperative benefits
    for j=1:num_agents_1
        non_Coop_benefit_p1(j,i)=sum(non_Coop_Ratio_pure_allReturn_demand(i).*Area_p1(:,j).*...
            Ratio_Mass_Area.*Ratio_Price_Mass);
    end
    for j=1:num_agents_2
        non_Coop_benefit_p2(j,i)=sum(non_Coop_Ratio_pure_allReturn_demand(i).*Area_p2(:,j).*...
            Ratio_Mass_Area.*Ratio_Price_Mass);
    end
    for j=1:num_agents_3
        non_Coop_benefit_p3(j,i)=sum(non_Coop_Ratio_pure_allReturn_demand(i).*Area_p3(:,j).*...
            Ratio_Mass_Area.*Ratio_Price_Mass);
    end
    for j=1:num_agents_4
        non_Coop_benefit_p4(j,i)=sum(non_Coop_Ratio_pure_allReturn_demand(i).*Area_p4(:,j).*...
            Ratio_Mass_Area.*Ratio_Price_Mass);
    end
    % calculation of cooperative benefits
    for j=1:num_agents_1
        Coal_02_benefit_p1(j,i)=sum(Coal_02_Ratio_pure_allReturn_demand_ABM_1(j,i).*Area_p1(:,j).*...
            Ratio_Mass_Area.*Ratio_Price_Mass);
        Coal_02_net_benefit(j,i)=Coal_02_benefit_p1(j,i)-non_Coop_benefit_p1(j,i);
    end
    for j=1:num_agents_2
        Coal_02_benefit_p2(j,i)=sum(Coal_02_Ratio_pure_allReturn_demand_ABM_2(j,i).*Area_p2(:,j).*...
            Ratio_Mass_Area.*Ratio_Price_Mass);
        Coal_02_net_benefit(num_agents_1+j,i)=Coal_02_benefit_p2(j,i)-non_Coop_benefit_p2(j,i);
    end
    for j=1:num_agents_3
        Coal_02_benefit_p3(j,i)=sum(Coal_02_Ratio_pure_allReturn_demand_ABM_3(j,i).*Area_p3(:,j).*...
            Ratio_Mass_Area.*Ratio_Price_Mass);
        Coal_02_net_benefit(num_agents_1+num_agents_2+j,i)=Coal_02_benefit_p3(j,i)-non_Coop_benefit_p3(j,i);
    end
    for j=1:num_agents_4
        Coal_02_benefit_p4(j,i)=sum(Coal_02_Ratio_pure_allReturn_demand_ABM_4(j,i).*Area_p4(:,j).*...
            Ratio_Mass_Area.*Ratio_Price_Mass);
        Coal_02_net_benefit(num_agents_1+num_agents_2+num_agents_3+j,i)=Coal_02_benefit_p4(j,i)-...
            non_Coop_benefit_p4(j,i);
    end
    Coal_02_Total_net_benefit(i)=sum(Coal_02_net_benefit(:,i));
    Coal_02_Total_benefit(i)=sum(Coal_02_benefit_p1(:,i)+Coal_02_benefit_p2(:,i)+...
        Coal_02_benefit_p3(:,i)+Coal_02_benefit_p4(:,i));
    Total_non_Coop_benefit(i)=sum(non_Coop_benefit_p1(:,i)+non_Coop_benefit_p2(:,i)+...
        non_Coop_benefit_p3(:,i)+non_Coop_benefit_p4(:,i));
    Coal_02_Ratio_benefit_Coal_non_Coop(i)=Coal_02_Total_benefit(i)./Total_non_Coop_benefit(i);
end
%% Part 4 : Assigning Ratio of Dam Allocations
% Ratio of allocation which will be supplied by dam release
% variables corresponding to each month for each user
% zeros are for month 9 & 10 of each year
Coal_02_Ratio_pure_all_dam_all_total_1=zeros(1,h);
Coal_02_Ratio_pure_all_dam_all_total_2=zeros(1,h);
Coal_02_Ratio_pure_all_dam_all_total_3=zeros(1,h);
Coal_02_Ratio_pure_all_dam_all_total_4=zeros(1,h);
for i=1:h/12
    Coal_02_Ratio_pure_all_dam_all_total_1((i-1)*12+1:i*12)=[0,0,variables(h/12+i).*ones(1,10)]; % Agricultural User # 1
    Coal_02_Ratio_pure_all_dam_all_total_2((i-1)*12+1:i*12)=[0,0,variables(2*h/12+i).*ones(1,10)]; % Agricultural User # 2
    Coal_02_Ratio_pure_all_dam_all_total_3((i-1)*12+1:i*12)=[0,0,variables(3*h/12+i).*ones(1,10)]; % Agricultural User # 3
    Coal_02_Ratio_pure_all_dam_all_total_4((i-1)*12+1:i*12)=[0,0,variables(4*h/12+i).*ones(1,10)]; % Agricultural User # 4
end
%% Part 5 : Computing Allocation from Dam and Groundwater
% Pure Allocation from dam release and groundwater supply plus drainage of upstream users
Coal_02_Pure_allReturn_1=zeros(1,h);
Coal_02_Pure_allReturn_2=zeros(1,h);
Coal_02_Pure_allReturn_3=zeros(1,h);
Coal_02_Pure_allReturn_4=zeros(1,h);
for i=1:h/12
    for j=1:num_agents_1
        Coal_02_Pure_allReturn_1((i-1)*12+1:i*12)=Coal_02_Pure_allReturn_1((i-1)*12+1:i*12)+...
            Coal_02_Ratio_pure_allReturn_demand_ABM_1(j,i).*D_1{j}((i-1)*12+1:i*12)';
    end
    for j=1:num_agents_2
        Coal_02_Pure_allReturn_2((i-1)*12+1:i*12)=Coal_02_Pure_allReturn_2((i-1)*12+1:i*12)+...
            Coal_02_Ratio_pure_allReturn_demand_ABM_2(j,i).*D_2{j}((i-1)*12+1:i*12)';
    end
    for j=1:num_agents_3
        Coal_02_Pure_allReturn_3((i-1)*12+1:i*12)=Coal_02_Pure_allReturn_3((i-1)*12+1:i*12)+...
            Coal_02_Ratio_pure_allReturn_demand_ABM_3(j,i).*D_3{j}((i-1)*12+1:i*12)';
    end
    for j=1:num_agents_4
        Coal_02_Pure_allReturn_4((i-1)*12+1:i*12)=Coal_02_Pure_allReturn_4((i-1)*12+1:i*12)+...
            Coal_02_Ratio_pure_allReturn_demand_ABM_4(j,i).*D_4{j}((i-1)*12+1:i*12)';
    end
end
% Allocations of Environment and Industries and Drinking
Coal_02_all_i=D_i'; % Industrial Allocation
Coal_02_all_dr=D_dr'; % Drinking Allocation
Coal_02_all_e=max(0,(D_e'-Ratio_return.*Coal_02_Pure_allReturn_4))./(eff_0_1.*eff_1_2.*eff_2_3.*eff_3_4); % Environmental Allocation
% allocation from ground water is equal to total allocation minus pure
% allocation from dam and Return Water
Coal_02_all_gr_1=Coal_02_Pure_allReturn_1-(Coal_02_Ratio_pure_all_dam_all_total_1.*Coal_02_Pure_allReturn_1);
% allocation from ground water is equal to total allocation minus pure
% allocation from dam and Return Water
Coal_02_all_gr_2=Coal_02_Pure_allReturn_2-(Coal_02_Ratio_pure_all_dam_all_total_2.*Coal_02_Pure_allReturn_2);
% allocation from ground water is equal to total allocation minus pure
% allocation from dam and Return Water
Coal_02_all_gr_3=Coal_02_Pure_allReturn_3-(Coal_02_Ratio_pure_all_dam_all_total_3.*Coal_02_Pure_allReturn_3);
% allocation from ground water is equal to total allocation minus pure
% allocation from dam and Return Water
Coal_02_all_gr_4=Coal_02_Pure_allReturn_4-(Coal_02_Ratio_pure_all_dam_all_total_4.*Coal_02_Pure_allReturn_4);
%% Part 6 : Calculation of River Flow
Coal_02_Environmental_Flow=Coal_02_all_e.*eff_0_1.*eff_1_2.*eff_2_3.*eff_3_4+Ratio_return.*Coal_02_Pure_allReturn_4;
Coal_02_flow_river_up_4=Coal_02_Pure_allReturn_4-Coal_02_all_gr_4;
Coal_02_flow_river_down_3=Coal_02_flow_river_up_4./eff_3_4;
Coal_02_flow_river_in_3=Coal_02_flow_river_down_3-Ratio_return.*Coal_02_Pure_allReturn_3;
Coal_02_flow_river_up_3=Coal_02_flow_river_in_3+Coal_02_Pure_allReturn_3-Coal_02_all_gr_3;
Coal_02_flow_river_down_2=Coal_02_flow_river_up_3./eff_2_3;
Coal_02_flow_river_in_2=Coal_02_flow_river_down_2-Ratio_return.*Coal_02_Pure_allReturn_2;
Coal_02_flow_river_up_2=Coal_02_flow_river_in_2+Coal_02_Pure_allReturn_2-Coal_02_all_gr_2;
Coal_02_flow_river_down_1=Coal_02_flow_river_up_2./eff_1_2;
Coal_02_flow_river_in_1=Coal_02_flow_river_down_1-Ratio_return.*Coal_02_Pure_allReturn_1;
Coal_02_flow_river_up_1=Coal_02_flow_river_in_1+Coal_02_Pure_allReturn_1-Coal_02_all_gr_1;
Coal_02_flow_river_down_0=Coal_02_flow_river_up_1./eff_0_1;
%% Part 7 : Allocation From Dam & Allocation From Return Water For Each User
Coal_02_all_dam_1=Coal_02_Pure_allReturn_1-Coal_02_all_gr_1;
Coal_02_all_return_1=zeros(1,h);
Coal_02_all_dam_2=(Coal_02_Pure_allReturn_2-Coal_02_all_gr_2)./(Coal_02_flow_river_up_2+eff_0_1.*eff_1_2.*Coal_02_all_e).*...
    (((Coal_02_flow_river_down_0+Coal_02_all_e).*eff_0_1-Coal_02_all_dam_1).*eff_1_2);
Coal_02_all_return_2=(Coal_02_Pure_allReturn_2-Coal_02_all_gr_2)./(Coal_02_flow_river_up_2+eff_0_1.*eff_1_2.*Coal_02_all_e).*...
    (Ratio_return.*Coal_02_Pure_allReturn_1-Coal_02_all_return_1).*eff_1_2;
Coal_02_all_dam_3=(Coal_02_Pure_allReturn_3-Coal_02_all_gr_3)./(Coal_02_flow_river_up_3+eff_0_1.*eff_1_2.*eff_2_3.*Coal_02_all_e).*...
    (((Coal_02_flow_river_down_0+Coal_02_all_e).*eff_0_1-Coal_02_all_dam_1).*eff_1_2-Coal_02_all_dam_2).*eff_2_3;
Coal_02_all_return_3=(Coal_02_Pure_allReturn_3-Coal_02_all_gr_3)./(Coal_02_flow_river_up_3+eff_0_1.*eff_1_2.*eff_2_3.*Coal_02_all_e).*...
    ((Ratio_return.*Coal_02_Pure_allReturn_1-Coal_02_all_return_1).*eff_1_2+...
    (Ratio_return.*Coal_02_Pure_allReturn_2-Coal_02_all_return_2)).*eff_2_3;
Coal_02_all_dam_4=(Coal_02_Pure_allReturn_4-Coal_02_all_gr_4)./(Coal_02_flow_river_up_4+eff_0_1.*eff_1_2.*eff_2_3.*eff_3_4.*Coal_02_all_e).*...
    ((((Coal_02_flow_river_down_0+Coal_02_all_e).*eff_0_1-Coal_02_all_dam_1).*eff_1_2-Coal_02_all_dam_2).*eff_2_3-Coal_02_all_dam_3).*eff_3_4;
Coal_02_all_return_4=(Coal_02_Pure_allReturn_4-Coal_02_all_gr_4)./(Coal_02_flow_river_up_3+eff_0_1.*eff_1_2.*eff_2_3.*eff_3_4.*Coal_02_all_e).*...
    (((Ratio_return.*Coal_02_Pure_allReturn_1-Coal_02_all_return_1).*eff_1_2+...
    (Ratio_return.*Coal_02_Pure_allReturn_2-Coal_02_all_return_2)).*eff_2_3+...
    (Ratio_return.*Coal_02_Pure_allReturn_3-Coal_02_all_return_3)).*eff_3_4;
% Violation of Flow
Coal_02_vio_f=abs((Coal_02_flow_river_down_0<0).*(Coal_02_flow_river_down_0))+abs((Coal_02_flow_river_up_1<0).*(Coal_02_flow_river_up_1))+...
    abs((Coal_02_flow_river_in_1<0).*(Coal_02_flow_river_in_1))+abs((Coal_02_flow_river_down_1<0).*(Coal_02_flow_river_down_1))+...
    abs((Coal_02_flow_river_up_2<0).*(Coal_02_flow_river_up_2))+abs((Coal_02_flow_river_in_2<0).*(Coal_02_flow_river_in_2))+...
    abs((Coal_02_flow_river_down_2<0).*(Coal_02_flow_river_down_2))+abs((Coal_02_flow_river_up_3<0).*(Coal_02_flow_river_up_3))+...
    abs((Coal_02_flow_river_in_3<0).*(Coal_02_flow_river_in_3))+abs((Coal_02_flow_river_down_3<0).*(Coal_02_flow_river_down_3))+...
    abs((Coal_02_flow_river_up_4<0).*(Coal_02_flow_river_up_4))+abs((Coal_02_all_dam_1<0).*(Coal_02_all_dam_1))+...
    abs((Coal_02_all_return_1<0).*(Coal_02_all_return_1))+abs((Coal_02_all_dam_2<0).*(Coal_02_all_dam_2))+...
    abs((Coal_02_all_return_2<0).*(Coal_02_all_return_2))+abs((Coal_02_all_dam_3<0).*(Coal_02_all_dam_3))+...
    abs((Coal_02_all_return_3<0).*(Coal_02_all_return_3))+abs((Coal_02_all_dam_4<0).*(Coal_02_all_dam_4))+...
    abs((Coal_02_all_return_4<0).*(Coal_02_all_return_4));
% Release From Dam
Coal_02_R=Coal_02_flow_river_down_0+Coal_02_all_e+Coal_02_all_i+Coal_02_all_dr;
%% Part 8 : Calculation of Storage of the Dam 
% Inflow
In=I';
% Preallocation of Storage, SPillway release, Excess Release, Violations
Coal_02_S=zeros(1,h+1);
Coal_02_S(1,1)=S1;
Coal_02_SP=zeros(1,h);
Coal_02_vio_S=zeros(1,h);
Coal_02_vio_R=zeros(1,h);
Coal_02_Vol_Rain=zeros(1,h);
Coal_02_Vol_E=zeros(1,h);
% Computing Billan & Violations
for i=1:h
    A=Vol_Area(Coal_02_S(i));
    Coal_02_Vol_Rain(i)=A.*Rain(i)./1000./1e6;
    Coal_02_Vol_E(i)=A.*E(i)./1000./1e6;
    Coal_02_S(i+1)=Coal_02_S(i)+In(i)+Coal_02_Vol_Rain(i)-Coal_02_Vol_E(i)-Coal_02_R(i);
    if Coal_02_S(i+1)<S_min
        Coal_02_vio_S(i)=abs(Coal_02_S(i+1)-S_min);
    elseif Coal_02_S(i+1)>=S_min && Coal_02_S(i+1)<=S_normal
        Coal_02_vio_S(i)=0;
    elseif Coal_02_S(i+1)>S_normal && Coal_02_S(i+1)<=S_max
        Coal_02_SP(i)=Coal_02_S(i+1)-S_normal;
        Coal_02_S(i+1)=S_normal;
        Coal_02_vio_S(i)=0;
    elseif Coal_02_S(i+1)>S_max
        Coal_02_vio_S(i)=abs(Coal_02_S(i+1)-S_normal);
    end
    if Coal_02_R(i)>S_max-S_min
        Coal_02_vio_R(i)=abs(Coal_02_R(i)-(S_max-S_min));
    end
end
%% Part 9 : Groundwater Calculations
% Toatal Groundwater Allocation
Coal_02_Allocation_gr=Coal_02_all_gr_1+Coal_02_all_gr_2+Coal_02_all_gr_3+Coal_02_all_gr_4;
% computing monthly drawdown of groundwater
Coal_02_dr_month_gr=net([Coal_02_all_gr_1;Coal_02_all_gr_2;Coal_02_all_gr_3;Coal_02_all_gr_4]);
% computing yearly drawdown of groundwater
Coal_02_dr_year_gr=zeros(1,h/12);
for i=1:h/12
    Coal_02_dr_year_gr(i)=sum(Coal_02_dr_month_gr((i-1)*h/(h/12)+1:i*h/(h/12)));
end
% computing violation of yearly drawdown of groundwater
Coal_02_vio_dr_gr=abs((Coal_02_dr_year_gr-allowable_dr>0).*(Coal_02_dr_year_gr-allowable_dr));
%% Part 10 : Calculation of Net Benefit
% Violation of Net Benefit
Coal_02_vio_net_benefit=abs((Coal_02_Total_net_benefit<0).*Coal_02_Total_net_benefit);