function [I,R,E,D_1_total,D_2_total,D_3_total,D_4_total,D_1,D_2,D_3,D_4,D_e,...
    D_i,D_dr,allowable_dr,lb,ub]=Read_Data_Text(Scenario,num_var,h)
% Determining Range of Reading data
if Scenario==1
    period=3;
elseif Scenario==2
    period=14;
elseif Scenario==3
    period=25;
end
f=h./12-1;
start_row=period;
end_row=start_row+f;
% Determining Delimiter in txt files
delimiter='\t';
% Determining Filenames
filename_I='Text\Inflow.txt';
filename_R='Text\Rain.txt';
filename_E='Text\Evaporation.txt';
filename_D_1='Text\1st User.txt';
filename_D_2='Text\2nd User.txt';
filename_D_3='Text\3rd User.txt';
filename_D_4='Text\4th User.txt';
filename_D_e='Text\Environmental.txt';
filename_D_i='Text\Industrial.txt';
filename_D_dr='Text\Drinking.txt';
filename_Gr='Text\Groundwater.txt';
% Determining Data type in files
formatSpec_wo_gr='%f%f%f%f%f%f%f%f%f%f%f%f%[^\n\r]';
formatSpec_gr='%f%[^\n\r]';
% Read Data for Inflow
fileID_I=fopen(filename_I,'r');
dataArray_I=textscan(fileID_I,formatSpec_wo_gr,'Delimiter',delimiter, 'ReturnOnError',false);
fclose(fileID_I);
Inflow=[dataArray_I{1:end-1}];
% Read Data for Rain
fileID_R=fopen(filename_R,'r');
dataArray_R=textscan(fileID_R,formatSpec_wo_gr,'Delimiter',delimiter, 'ReturnOnError',false);
fclose(fileID_R);
Rain=[dataArray_R{1:end-1}];
% Read Data for Evaporation
fileID_E=fopen(filename_E,'r');
dataArray_E=textscan(fileID_E,formatSpec_wo_gr,'Delimiter',delimiter, 'ReturnOnError',false);
fclose(fileID_E);
Evaporation=[dataArray_E{1:end-1}];
% Read Data for User 1 Demand
fileID_D_1=fopen(filename_D_1,'r');
dataArray_D_1=textscan(fileID_D_1,formatSpec_wo_gr,'Delimiter',delimiter, 'ReturnOnError',false);
fclose(fileID_D_1);
Demand_1=[dataArray_D_1{1:end-1}];
% Read Data for User 2 Demand
fileID_D_2=fopen(filename_D_2,'r');
dataArray_D_2=textscan(fileID_D_2,formatSpec_wo_gr,'Delimiter',delimiter, 'ReturnOnError',false);
fclose(fileID_D_2);
Demand_2=[dataArray_D_2{1:end-1}];
% Read Data for User 3 Demand
fileID_D_3=fopen(filename_D_3,'r');
dataArray_D_3=textscan(fileID_D_3,formatSpec_wo_gr,'Delimiter',delimiter, 'ReturnOnError',false);
fclose(fileID_D_3);
Demand_3=[dataArray_D_3{1:end-1}];
% Read Data for User 4 Demand
fileID_D_4=fopen(filename_D_4,'r');
dataArray_D_4=textscan(fileID_D_4,formatSpec_wo_gr,'Delimiter',delimiter, 'ReturnOnError',false);
fclose(fileID_D_4);
Demand_4=[dataArray_D_4{1:end-1}];
% Read Data for Environmental Demand
fileID_D_e=fopen(filename_D_e,'r');
dataArray_D_e=textscan(fileID_D_e,formatSpec_wo_gr,'Delimiter',delimiter, 'ReturnOnError',false);
fclose(fileID_D_e);
Demand_e=[dataArray_D_e{1:end-1}];
% Read Data for Industrial Demand
fileID_D_i=fopen(filename_D_i,'r');
dataArray_D_i=textscan(fileID_D_i,formatSpec_wo_gr,'Delimiter',delimiter, 'ReturnOnError',false);
fclose(fileID_D_i);
Demand_i=[dataArray_D_i{1:end-1}];
% Read Data for Drinking Demand
fileID_D_dr=fopen(filename_D_dr,'r');
dataArray_D_dr=textscan(fileID_D_dr,formatSpec_wo_gr,'Delimiter',delimiter, 'ReturnOnError',false);
fclose(fileID_D_dr);
Demand_dr=[dataArray_D_dr{1:end-1}];
% Read Data for Allowable Groundwater
fileID_gr=fopen(filename_Gr,'r');
dataArray_gr=textscan(fileID_gr,formatSpec_gr,'Delimiter',delimiter, 'ReturnOnError',false);
fclose(fileID_gr);
Groundwater=[dataArray_gr{1:end-1}];
if Scenario==1
    allowable_dr=Groundwater(1);
elseif Scenario==2
    allowable_dr=Groundwater(2);
elseif Scenario==3
    allowable_dr=Groundwater(3);
end
% Determining the required data
I=Inflow(start_row:end_row,1:h/(f+1));
R=Rain(start_row:end_row,1:h/(f+1));
E=Evaporation(start_row:end_row,1:h/(f+1));
D_1_total=sum(Demand_1,1);
D_2_total=sum(Demand_2,1);
D_3_total=sum(Demand_3,1);
D_4_total=sum(Demand_4,1);
D_e=Demand_e(start_row:end_row,1:h/(f+1));
D_i=Demand_i(start_row:end_row,1:h/(f+1));
D_dr=Demand_dr(start_row:end_row,1:h/(f+1));
I=I';
E=E';
R=R';
D_1_total=D_1_total';
D_2_total=D_2_total';
D_3_total=D_3_total';
D_4_total=D_4_total';
D_e=D_e';
D_i=D_i';
D_dr=D_dr';
I=reshape(I,[h 1]);
E=reshape(E,[h 1]);
R=reshape(R,[h 1]);
D_1_total=repmat(D_1_total,[h/12 1]);
D_2_total=repmat(D_2_total,[h/12 1]);
D_3_total=repmat(D_3_total,[h/12 1]);
D_4_total=repmat(D_4_total,[h/12 1]);
D_1=cell(20,1);
D_2=cell(20,1);
D_3=cell(20,1);
D_4=cell(20,1);
% Determining Demands of each agent
for i=1:20
    D_1{i}=repmat(Demand_1(i,:)',[h/12,1]);
    D_2{i}=repmat(Demand_2(i,:)',[h/12,1]);
    D_3{i}=repmat(Demand_3(i,:)',[h/12,1]);
    D_4{i}=repmat(Demand_4(i,:)',[h/12,1]);
end
D_e=reshape(D_e,[h 1]);
D_i=reshape(D_i,[h 1]);
D_dr=reshape(D_dr,[h 1]);
lb=zeros(1,num_var);
ub=ones(1,num_var);
end