clc
clear
% run('Coalition_00_p1_p2_p3_p4_ABM.m')
run('Coalition_01_p1_p2_ABM.m')
run('Coalition_02_p1_p3_ABM.m')
run('Coalition_03_p1_p4_ABM.m')
run('Coalition_04_p2_p3_ABM.m')
run('Coalition_05_p2_p4_ABM.m')
run('Coalition_06_p3_p4_ABM.m')
run('Coalition_07_p1_p2_p3_ABM.m')
run('Coalition_08_p1_p2_p4_ABM.m')
run('Coalition_09_p1_p3_p4_ABM.m')
run('Coalition_10_p2_p3_p4_ABM.m')
% run('Coalition_11_p1_p2_p3_p4_ABM.m')